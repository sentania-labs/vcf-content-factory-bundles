#!/usr/bin/env python3
"""VCF Operations content installer/uninstaller.

Installs or uninstalls one or more content bundles found in the bundles/
subdirectory (or a legacy top-level content/ directory).  When multiple
bundles are present, an interactive checklist is shown so the operator can
select which bundles to install or uninstall.

Usage (install, fully interactive -- prompts for all credentials):
    python3 install.py
    python3 install.py --install

Usage (uninstall):
    python3 install.py --uninstall
    python3 install.py --uninstall --force   # skip dependency checks

Note: Uninstall requires the 'admin' account for dashboard/view cleanup.

Usage (explicit flags):
    python3 install.py --host ops.example.com --user admin --password secret
    python3 install.py --uninstall --host ops.example.com --user admin --password secret

Usage (env vars):
    VCFOPS_HOST=ops.example.com VCFOPS_USER=admin VCFOPS_PASSWORD=secret python3 install.py

Args take precedence over env vars; env vars take precedence over interactive prompts.

Exit codes:
    0 -- success (all content installed/removed)
    1 -- fatal error (auth failure, unexpected API error)
    2 -- partial failure (some items skipped or failed; others succeeded)

Requires Python 3.8+. Uses only stdlib plus `requests` (auto-installed
into a temporary venv if not already available).
"""

from __future__ import annotations

import argparse
import base64
import getpass
import io
import json
import os
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Narration must never be able to fail an install (issue #118).
#
# #101 pinned encoding= on this file's text I/O. That covers files only. This
# installer also PRINTS bundle-sourced content names -- view names, dashboard
# names -- and on a customer's native-Windows box with stdout redirected to a
# file or a pipe, Python encodes stdout with the locale encoding (cp1252 on a
# US box). A content name carrying a character outside cp1252 then raises
# UnicodeEncodeError *after the object has already been created on the
# instance*: the work succeeded and the report of it crashed, leaving the
# operator with a traceback over a partially narrated install.
#
# errors="replace" is the load-bearing half. Pinning utf-8 alone would still
# raise on a surrogate or an unencodable code point; "replace" guarantees the
# print always completes. A mangled character in a printed name is cosmetic.
# A traceback after a successful import is not.
#
# stderr gets the same treatment: _die() writes there, and a message about a
# failure must not itself fail.
#
# This runs at import time, before _bootstrap_requests(), because the
# bootstrap prints a temp-directory path that can carry a non-ASCII Windows
# username -- so main() would already be too late.
def _pin_stdio_encoding() -> None:
    for stream in (sys.stdout, sys.stderr):
        # hasattr guard: sys.stdout is only guaranteed to be a TextIOWrapper
        # when it is a real stream. Under a capture harness, or when stdout is
        # closed, it may be some other file-like object with no reconfigure().
        # Failing to pin is the status quo ante; raising here would break the
        # installer on the very platforms it already worked on.
        try:
            reconfigure = getattr(stream, "reconfigure", None)
            if reconfigure is not None:
                reconfigure(encoding="utf-8", errors="replace")
        except (ValueError, OSError):
            pass


_pin_stdio_encoding()


# ---------------------------------------------------------------------------
# Bootstrap: ensure `requests` is available. If not, create a temp venv,
# install it, and re-exec this script inside the venv with all original args.
# ---------------------------------------------------------------------------
def _bootstrap_requests() -> None:
    try:
        import requests  # noqa: F401
        return
    except ImportError:
        pass

    import tempfile, venv
    venv_dir = Path(tempfile.mkdtemp(prefix="vcfops_install_venv_"))
    print(f"[bootstrap] Creating venv at {venv_dir} to install requests...")
    venv.create(str(venv_dir), with_pip=True)
    pip = venv_dir / "bin" / "pip"
    if not pip.exists():
        pip = venv_dir / "Scripts" / "pip.exe"
    subprocess.check_call([str(pip), "install", "--quiet", "requests"])
    python = venv_dir / "bin" / "python3"
    if not python.exists():
        python = venv_dir / "Scripts" / "python.exe"
    # Pass all original args through to the re-exec'd interpreter so flags
    # and env vars survive the bootstrap boundary.
    os.execv(str(python), [str(python)] + sys.argv)

_bootstrap_requests()

import requests  # noqa: E402 -- after bootstrap
import urllib3   # noqa: E402


class _VerifyRespectingSession(requests.Session):
    """requests.Session whose verify=False is not overridden by the environment.

    Plain requests lets REQUESTS_CA_BUNDLE / CURL_CA_BUNDLE replace
    Session.verify = False when a request does not pass verify= itself, so
    --skip-ssl-verify (or VCFOPS_VERIFY_SSL=false) silently turns validation back on
    against the exported bundle. Here a session set to verify=False stays
    False; verify=True still honours the env bundle. Mirrors
    vcfcf_common.client.VerifyRespectingSession (this script is standalone).
    """

    def merge_environment_settings(self, url, proxies, stream, verify, cert):
        if verify is None and self.verify is False:
            verify = False
        return super().merge_environment_settings(url, proxies, stream, verify, cert)


def _new_session(verify_ssl: bool) -> "requests.Session":
    s = _VerifyRespectingSession()
    s.verify = verify_ssl
    return s


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).parent


def _load_json_from_path(p: Path) -> Any:
    return json.loads(p.read_text(encoding="utf-8"))


def _bundle_display_name(bundle: Dict) -> str:
    """Return the human-readable display name for a bundle.

    Reads manifest["display_name"] when present (set by builder at package
    time).  Falls back to manifest["name"] for legacy zips built before the
    display_name field was introduced.
    """
    manifest = bundle["manifest"]
    return manifest.get("display_name") or manifest.get("name") or bundle["slug"]


# ---------------------------------------------------------------------------
# Bundle discovery and selection
# ---------------------------------------------------------------------------
def _discover_bundles() -> List[Dict]:
    """Discover bundle entries from the bundles/ subtree.

    Returns a list of dicts:
        {"slug": str, "dir": Path, "manifest": dict}

    Fallback: if no bundles/ subtree exists but a legacy top-level bundle.json
    + content/ exist, synthesise a single in-memory entry for backwards
    compatibility (one-release transition; removable later).
    """
    bundles_root = SCRIPT_DIR / "bundles"
    entries: List[Dict] = []

    if bundles_root.exists():
        for bundle_json_path in sorted(bundles_root.glob("*/bundle.json")):
            slug = bundle_json_path.parent.name
            try:
                manifest = json.loads(bundle_json_path.read_text(encoding="utf-8"))
            except Exception as exc:
                print(f"  WARN  Could not parse {bundle_json_path}: {exc} -- skipping")
                continue
            entries.append({
                "slug": slug,
                "dir": bundle_json_path.parent,
                "manifest": manifest,
            })

    if not entries:
        # Legacy fallback: flat content/ layout with top-level bundle.json.
        legacy_manifest_path = SCRIPT_DIR / "bundle.json"
        legacy_content_dir = SCRIPT_DIR / "content"
        if legacy_manifest_path.exists() and legacy_content_dir.exists():
            try:
                manifest = json.loads(legacy_manifest_path.read_text(encoding="utf-8"))
            except Exception:
                manifest = {"name": "bundle", "description": "", "content": {}}
            # Synthesise a content map pointing to the legacy content/ directory.
            # Rewrite file paths to be relative to SCRIPT_DIR so the install
            # handlers can resolve them via bundle_dir / file.
            content = manifest.get("content") or {}
            for key, section in content.items():
                rel = section.get("file", "")
                if rel and not rel.startswith("content/"):
                    section["file"] = f"content/{rel}"
            entries.append({
                "slug": manifest.get("name", "bundle"),
                "dir": SCRIPT_DIR,
                "manifest": manifest,
            })
        elif legacy_content_dir.exists():
            # Minimal fallback with no manifest at all, synthesise from files.
            manifest = {"name": "bundle", "description": "", "content": {}}
            legacy_files = {
                "supermetrics": "supermetrics.json",
                "views": "views_content.xml",
                "dashboards": "dashboard.json",
                "customgroups": "customgroup.json",
                "symptoms": "symptoms.json",
                "alerts": "alerts.json",
                "reports": "reports_content.xml",
            }
            content: dict = {}
            for key, fname in legacy_files.items():
                if (legacy_content_dir / fname).exists():
                    content[key] = {"file": f"content/{fname}", "items": []}
            manifest["content"] = content
            entries.append({
                "slug": "bundle",
                "dir": SCRIPT_DIR,
                "manifest": manifest,
            })

    return entries


def _select_bundles(bundles: List[Dict], mode: str) -> List[Dict]:
    """Interactive multi-select checklist for bundles.

    Single bundle: auto-select and return it without prompting.
    Multiple bundles: print checklist (all checked by default),
    accept comma-separated toggle indices, 'all', 'none', or empty to proceed.

    Returns the list of selected bundle dicts.
    """
    if len(bundles) == 1:
        b = bundles[0]
        name = _bundle_display_name(b)
        desc = b["manifest"].get("description", "")
        print(f"\n  Bundle: {name}" + (f" -- {desc}" if desc else ""))
        return bundles

    print(f"\nSelect bundles to {mode} (all selected by default):")
    print("  Toggle: enter comma-separated numbers (e.g. '2' or '1,3')")
    print("  Commands: 'all' to select all, 'none' to deselect all, Enter to proceed")
    print()

    selected = [True] * len(bundles)

    while True:
        for i, b in enumerate(bundles, 1):
            mark = "*" if selected[i - 1] else " "
            name = _bundle_display_name(b)
            desc = b["manifest"].get("description", "")
            n_items = sum(
                len(s.get("items", []))
                for s in b["manifest"].get("content", {}).values()
            )
            detail = f"{n_items} items" if n_items else "no items"
            suffix = f" ({detail})" + (f" -- {desc}" if desc else "")
            print(f"  [{mark}] {i}. {name}{suffix}")

        raw = input("\nToggle [1..N / all / none / Enter to proceed]: ").strip().lower()
        if raw == "":
            break
        elif raw == "all":
            selected = [True] * len(bundles)
        elif raw == "none":
            selected = [False] * len(bundles)
        else:
            for tok in raw.split(","):
                tok = tok.strip()
                if tok.isdigit():
                    idx = int(tok) - 1
                    if 0 <= idx < len(bundles):
                        selected[idx] = not selected[idx]
                    else:
                        print(f"  (ignoring out-of-range index {tok})")
                elif tok:
                    print(f"  (unrecognised token {tok!r} -- ignored)")
        print()

    chosen = [b for b, s in zip(bundles, selected) if s]
    if not chosen:
        print("  No bundles selected. Exiting.")
        sys.exit(0)
    return chosen


def _print_selection_summary(bundles: List[Dict], mode: str) -> None:
    """Print a summary of selected bundles before install/uninstall."""
    print(f"\nWill {mode} {len(bundles)} bundle(s):")
    for b in bundles:
        name = _bundle_display_name(b)
        desc = b["manifest"].get("description", "")
        content = b["manifest"].get("content", {})
        parts: List[str] = []
        for key, section in content.items():
            count = len(section.get("items", []))
            if count:
                parts.append(f"{count} {key}")
        summary = ", ".join(parts) if parts else "no items"
        print(f"  - {name}" + (f" -- {desc}" if desc else ""))
        print(f"    Contents: {summary}")


def _die(msg: str) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def _ok(msg: str) -> None:
    print(f"  OK  {msg}")


def _warn(msg: str) -> None:
    print(f"  WARN  {msg}")


def _verify_supermetrics_enabled(policy_xml: str, sm_ids: list) -> dict:
    """Check which SM IDs appear as enabled in policy XML."""
    root = ET.fromstring(policy_xml)
    enabled_ids = set()
    for elem in root.iter("SuperMetric"):
        if elem.get("enabled", "").lower() == "true":
            enabled_ids.add(elem.get("id", ""))
    return {sm_id: sm_id in enabled_ids for sm_id in sm_ids}


def _step(n: int, total: int, msg: str) -> None:
    print(f"\n[{n}/{total}] {msg}")


def _resolve_auth_source(raw: str) -> str:
    """Normalise the user-supplied auth source string.

    'local' (case-insensitive) or empty -> 'Local' (Suite API canonical value).
    Anything else (e.g. 'corp.example.com') -> returned as-is.

    Each client is responsible for translating 'Local' to the value its own
    API endpoint expects:
      - Suite API (/suite-api/api/auth/token/acquire): authSource = "Local"
      - UI login (/ui/login.action): authSourceId = "localItem"
    """
    if not raw or raw.strip().lower() == "local":
        return "Local"
    return raw.strip()


# ---------------------------------------------------------------------------
# VCF Ops Suite API client (thin wrapper around requests.Session)
# ---------------------------------------------------------------------------
class Client:
    def __init__(self, host: str, user: str, password: str,
                 auth_source: str = "Local", verify_ssl: bool = True):
        self.base = f"https://{host}/suite-api"
        self._user = user
        self._password = password
        self._auth_source = auth_source
        self._session = _new_session(verify_ssl)
        self._session.headers.update({
            "Accept": "application/json",
            "Content-Type": "application/json",
        })
        self._token: Optional[str] = None

    def authenticate(self) -> None:
        r = self._session.post(
            f"{self.base}/api/auth/token/acquire",
            json={"username": self._user, "password": self._password,
                  "authSource": self._auth_source},
        )
        if r.status_code != 200:
            _die(f"Authentication failed ({r.status_code}): {r.text}")
        self._token = r.json()["token"]
        self._session.headers["Authorization"] = f"vRealizeOpsToken {self._token}"

    def _req(self, method: str, path: str, **kw) -> requests.Response:
        if not self._token:
            self.authenticate()
        r = self._session.request(method, f"{self.base}{path}", **kw)
        if r.status_code == 401:
            self._token = None
            self.authenticate()
            r = self._session.request(method, f"{self.base}{path}", **kw)
        return r

    def get_current_user(self) -> dict:
        r = self._req("GET", "/api/auth/currentuser")
        if r.status_code != 200:
            _die(f"currentuser failed ({r.status_code}): {r.text}")
        return r.json()

    def get_ops_version(self):
        """Product version from GET /api/versions/current releaseName, or
        None when it cannot be read (same rule as the factory's
        vcfcf_dashboards.client.get_ops_version)."""
        try:
            r = self._req("GET", "/api/versions/current")
            if r.status_code != 200:
                return None
            return _parse_release_name((r.json() or {}).get("releaseName"))
        except Exception:  # noqa: BLE001
            return None

    def discover_marker_filename(self, timeout_s: int = 120) -> str:
        """Discover the target's *L.v1 marker filename via a throwaway export.

        The importer rejects bundles whose marker filename does not match
        the server's own value. The value has been identical on every
        instance examined (8.18.7 to 9.1.1), but is read from the target
        as insurance. Snapshot startTime before POST so a stale
        FINISHED state from a prior export isn't mistaken for our new one.
        """
        deadline = time.monotonic() + timeout_s
        # This loop deliberately keeps polling through a non-200 rather than
        # dying on the first transient, so at timeout `st` is not evidence of
        # anything: it holds the last value seen on a 200, or "" if there
        # never was one. Naming the last-seen signal is what tells an operator
        # whether the API was returning 500s the whole time or genuinely
        # reported a stuck export. install.ps1's sibling loop got this in
        # #120; this is the Python half of the same parity (issue #121).
        last_seen = "no status response yet"
        while True:
            g = self._req("GET", "/api/content/operations/export")
            if g.status_code == 200:
                st = (g.json() or {}).get("state", "")
                last_seen = f"state={st}"
                if st not in ("RUNNING", "INITIALIZED"):
                    break
            else:
                last_seen = f"HTTP {g.status_code}"
            if time.monotonic() > deadline:
                _die("Timed out waiting for prior export to finish "
                     f"(last seen: {last_seen})")
            time.sleep(2)

        prior_start = 0
        g = self._req("GET", "/api/content/operations/export")
        if g.status_code == 200:
            prior_start = (g.json() or {}).get("startTime") or 0

        r = self._req("POST", "/api/content/operations/export",
                      json={"scope": "CUSTOM", "contentTypes": ["SUPER_METRICS"]})
        if r.status_code not in (200, 202):
            _die(f"Marker-probe export failed ({r.status_code}): {r.text}")

        deadline = time.monotonic() + timeout_s
        while True:
            g = self._req("GET", "/api/content/operations/export")
            if g.status_code != 200:
                _die(f"Export status check failed ({g.status_code}): {g.text}")
            body = g.json() or {}
            st = body.get("state", "")
            start_time = body.get("startTime") or 0
            if start_time > prior_start and st.startswith("FINI"):
                break
            if time.monotonic() > deadline:
                _die(f"Marker-probe export timed out; state={st}")
            time.sleep(2)

        z = self._session.get(f"{self.base}/api/content/operations/export/zip")
        if z.status_code != 200:
            _die(f"Export zip download failed ({z.status_code})")
        with zipfile.ZipFile(io.BytesIO(z.content)) as zf:
            for name in zf.namelist():
                if name.endswith("L.v1"):
                    return name
        _die("Export zip did not contain a *L.v1 marker file")
        return ""  # unreachable

    def import_content_zip(self, zip_bytes: bytes, label: str,
                           timeout_s: int = 180, retries: int = 4) -> None:
        """POST a content-zip to the import endpoint and poll until done.

        A 403 'task already running' is retried with exponential backoff.
        endTime is snapshotted before POST so the poll can distinguish our
        import from a prior already-FINISHED one.
        """
        pre = self._req("GET", "/api/content/operations/import")
        prior_end = 0
        if pre.status_code == 200:
            prior_end = (pre.json() or {}).get("endTime") or 0

        for attempt in range(1, retries + 1):
            r = self._session.post(
                f"{self.base}/api/content/operations/import",
                headers={"Content-Type": None},
                params={"force": "true"},
                files={"contentFile": ("content.zip", zip_bytes, "application/zip")},
            )
            if r.status_code == 403:
                wait = 2 ** attempt
                print(f"    [retry {attempt}/{retries}] 403 task busy, waiting {wait}s...")
                time.sleep(wait)
                continue
            if r.status_code not in (200, 202):
                _die(f"Import POST failed for {label} ({r.status_code}): {r.text}")
            break
        else:
            _die(f"Import POST for {label} failed after {retries} retries (task busy)")

        deadline = time.monotonic() + timeout_s
        while True:
            s = self._req("GET", "/api/content/operations/import")
            if s.status_code != 200:
                _die(f"Import status check failed ({s.status_code}): {s.text}")
            body = s.json()
            state = body.get("state", "")
            end_time = body.get("endTime") or 0
            if end_time > prior_end and state not in ("RUNNING", "INITIALIZED"):
                if "FAIL" in state.upper():
                    _die(f"Import of {label} finished with state={state}")
                # Check per-content-type summaries for partial failures even
                # when the top-level state is FINISHED.
                for os_entry in body.get("operationSummaries") or []:
                    os_state = os_entry.get("state", "")
                    os_failed = os_entry.get("failed", 0) or 0
                    os_skipped = os_entry.get("skipped", 0) or 0
                    os_imported = os_entry.get("imported", 0) or 0
                    ct = os_entry.get("contentType", "?")
                    if os_state not in ("FINISHED", "") or os_failed > 0 or os_skipped > 0:
                        print(
                            f"WARN: content type {ct}: "
                            f"imported={os_imported} skipped={os_skipped} "
                            f"failed={os_failed} state={os_state}"
                        )
                return body
            if time.monotonic() > deadline:
                _die(f"Import of {label} did not finish in {timeout_s}s; state={state}")
            time.sleep(2)
        return {}  # unreachable; satisfies type checkers

    def export_dashboards_zip(self, timeout_s: int = 180) -> bytes:
        """One CUSTOM DASHBOARDS export (read-only: it creates no content).

        Used only by the post-install materialization check, which is
        advisory, so every failure raises RuntimeError instead of _die().
        Same sequence as the factory's export_content_zip: wait for any
        export in flight, snapshot startTime, POST, poll for a newer
        FINISHED run.
        """
        deadline = time.monotonic() + timeout_s
        while True:
            g = self._req("GET", "/api/content/operations/export")
            if g.status_code == 200:
                if (g.json() or {}).get("state", "") not in ("RUNNING", "INITIALIZED"):
                    break
            if time.monotonic() > deadline:
                raise RuntimeError("timed out waiting for a prior export to finish")
            time.sleep(2)
        prior_start = 0
        g = self._req("GET", "/api/content/operations/export")
        if g.status_code == 200:
            prior_start = (g.json() or {}).get("startTime") or 0
        r = self._req("POST", "/api/content/operations/export",
                      json={"scope": "CUSTOM", "contentTypes": ["DASHBOARDS"]})
        if r.status_code not in (200, 202):
            raise RuntimeError(f"dashboard export failed ({r.status_code}): {r.text[:300]}")
        deadline = time.monotonic() + timeout_s
        while True:
            g = self._req("GET", "/api/content/operations/export")
            if g.status_code != 200:
                raise RuntimeError(f"export status failed ({g.status_code})")
            body = g.json() or {}
            if (body.get("startTime") or 0) > prior_start and \
                    str(body.get("state", "")).startswith("FINI"):
                break
            if time.monotonic() > deadline:
                raise RuntimeError(f"dashboard export timed out; state={body.get('state')}")
            time.sleep(2)
        z = self._session.get(f"{self.base}/api/content/operations/export/zip")
        if z.status_code != 200:
            raise RuntimeError(f"export zip download failed ({z.status_code})")
        return z.content

    def list_adapter_kind_keys(self) -> set:
        """Adapter-kind keys installed on the target (GET /api/adapterkinds)."""
        r = self._req("GET", "/api/adapterkinds")
        if r.status_code != 200:
            raise RuntimeError(f"adapterkinds read failed ({r.status_code})")
        return {
            str(ak.get("key"))
            for ak in ((r.json() or {}).get("adapter-kind") or [])
            if isinstance(ak, dict) and ak.get("key")
        }

    def get_default_policy_id(self) -> str:
        r = self._req("GET", "/api/policies")
        if r.status_code != 200:
            _die(f"Policy list failed ({r.status_code}): {r.text}")
        for p in r.json().get("policySummaries") or []:
            if p.get("defaultPolicy"):
                return p["id"]
        _die("No default policy found in /api/policies")
        return ""

    def list_supermetrics_by_name(self, names: List[str]) -> Dict[str, str]:
        """Return {name: id} for the given SM names (case-sensitive exact match).

        Uses the server-resolved ID for the enable step, the content-zip
        importer may assign a different server-side ID than the UUID in the
        YAML, so we resolve by name after import rather than trusting the
        pre-import UUID.
        """
        found: Dict[str, str] = {}
        page, page_size = 0, 1000
        target = set(names)
        while True:
            r = self._req("GET", "/api/supermetrics",
                          params={"page": page, "pageSize": page_size})
            if r.status_code != 200:
                _die(f"Super metric list failed ({r.status_code}): {r.text}")
            body = r.json()
            items = body.get("superMetrics") or []
            for sm in items:
                if sm.get("name") in target:
                    found[sm["name"]] = sm["id"]
            info = body.get("pageInfo") or {}
            total = info.get("totalCount", len(items))
            if (page + 1) * page_size >= total or not items:
                break
            page += 1
        return found

    def enable_sm_on_default_policy(self, sm_id: str, sm_name: str,
                                    resource_kinds: list) -> None:
        """Assign a super metric to resource kinds and enable it in the
        Default Policy.

        Two-step approach required for content-zip-imported SMs:

        Step 1: resource-kind assignment via PUT /internal/supermetrics/assign
          (without policyIds).  Wires the SM to adapter/resource kind so it
          appears in views.  The policyIds variant does NOT enable content-zip
          SMs on any policy, it is a no-op for this import path.

        Step 2: policy enablement via policy export -> edit XML -> re-import.
          Stale entries for this SM are removed from ALL <SuperMetrics> blocks
          before injecting fresh ones, making this call idempotent/self-healing.
        """
        import re as _re

        policy_id = self.get_default_policy_id()

        # Step 1: resource-kind assignment (no policyIds).
        normalised_rks = [
            {
                "adapterKind": rk.get("adapterKindKey") or rk.get("adapterKind"),
                "resourceKind": rk.get("resourceKindKey") or rk.get("resourceKind"),
            }
            for rk in resource_kinds
        ]
        body = {
            "superMetricId": sm_id,
            "resourceKindKeys": normalised_rks,
        }
        r = self._req(
            "PUT",
            "/internal/supermetrics/assign",
            json=body,
            headers={"X-Ops-API-use-unsupported": "true"},
        )
        if r.status_code != 200:
            raise RuntimeError(
                f"Resource-kind assignment for SM '{sm_name}' failed "
                f"({r.status_code}): {r.text}"
            )

        # Step 2: policy export -> edit XML -> re-import.
        r = self._req(
            "GET", "/api/policies/export",
            params={"id": policy_id},
            headers={"Accept": "application/zip"},
        )
        if r.status_code != 200:
            raise RuntimeError(
                f"Policy export failed ({r.status_code}): {r.text}"
            )

        zip_bytes = r.content
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            xml_names = [n for n in zf.namelist() if n.endswith(".xml")]
            if not xml_names:
                raise RuntimeError("Policy export ZIP contained no XML file")
            xml_name = xml_names[0]
            raw_xml = zf.read(xml_name)
            other_files = {n: zf.read(n) for n in zf.namelist() if n != xml_name}

        # Register namespaces so round-trip preserves prefixes.
        for prefix, uri in _re.findall(
            r'xmlns(?::([A-Za-z_][A-Za-z0-9_.-]*))?=["\']([^"\']+)["\']',
            raw_xml.decode("utf-8"),
        ):
            ET.register_namespace(prefix if prefix else "", uri)

        root = ET.fromstring(raw_xml)

        # Locate <PackageSettings>.
        pkg_settings = root.find(".//{*}PackageSettings")
        if pkg_settings is None:
            pkg_settings = root.find(".//PackageSettings")
        if pkg_settings is None:
            policy_elem = root.find(".//{*}Policy")
            if policy_elem is None:
                policy_elem = root.find(".//Policy")
            if policy_elem is None:
                raise RuntimeError(
                    f"Policy XML has no <Policy> element, cannot inject SM '{sm_name}'"
                )
            pkg_settings = ET.SubElement(policy_elem, "PackageSettings")

        # Purge stale entries for this SM from ALL SuperMetrics blocks.
        all_sm_blocks = (
            pkg_settings.findall("{*}SuperMetrics")
            or pkg_settings.findall("SuperMetrics")
        )
        for block in all_sm_blocks:
            for entry in list(block):
                entry_tag = (
                    entry.tag.split("}")[-1] if "}" in entry.tag else entry.tag
                )
                if entry_tag == "SuperMetric" and entry.get("id") == sm_id:
                    block.remove(entry)

        # Inject fresh enabled entries for each resource kind.
        for rk in normalised_rks:
            adapter_kind = rk["adapterKind"]
            resource_kind = rk["resourceKind"]

            sm_block = None
            for candidate in (
                pkg_settings.findall("{*}SuperMetrics")
                or pkg_settings.findall("SuperMetrics")
            ):
                if (
                    candidate.get("adapterKind") == adapter_kind
                    and candidate.get("resourceKind") == resource_kind
                ):
                    sm_block = candidate
                    break

            if sm_block is None:
                sm_block = ET.SubElement(
                    pkg_settings,
                    "SuperMetrics",
                    {"adapterKind": adapter_kind, "resourceKind": resource_kind},
                )

            ET.SubElement(sm_block, "SuperMetric", {"enabled": "true", "id": sm_id})

        # Serialise and rebuild ZIP.
        edited_xml = ET.tostring(root, encoding="unicode", xml_declaration=False)
        if not edited_xml.startswith("<?xml"):
            edited_xml = '<?xml version="1.0" encoding="UTF-8"?>\n' + edited_xml
        edited_xml_bytes = edited_xml.encode("utf-8")

        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(xml_name, edited_xml_bytes)
            for name, data in other_files.items():
                zf.writestr(name, data)
        zip_out = buf.getvalue()

        # POST the rebuilt ZIP to /api/policies/import?forceImport=true.
        # Must not send Content-Type: application/json for multipart uploads.
        saved_ct = self._session.headers.pop("Content-Type", None)
        try:
            r = self._session.post(
                f"{self.base}/api/policies/import",
                params={"forceImport": "true"},
                files={"policy": ("exportedPolicies.zip", zip_out, "application/zip")},
            )
        finally:
            if saved_ct is not None:
                self._session.headers["Content-Type"] = saved_ct
        if r.status_code not in (200, 201, 204):
            raise RuntimeError(
                f"Policy import failed for SM '{sm_name}' ({r.status_code}): {r.text}"
            )

    def enable_builtin_metrics_on_default_policy(
        self,
        entries: list,
    ) -> dict:
        """Enable built-in object-type metrics on the Default Policy.

        Injects <Metrics adapterKind=... resourceKind=...><Metric enabled="true"
        id=.../>...</Metrics> blocks into exportedPolicies.xml under
        <PackageSettings>, then re-imports the ZIP.  Idempotent: stale <Metric>
        entries for keys being injected are purged before fresh entries are
        written.  Entries for keys NOT being touched are preserved.

        Args:
            entries: list of dicts with keys adapter_kind, resource_kind,
                     metric_key (all str).

        Returns:
            dict mapping metric_key -> bool (True = was already enabled before
            this call).
        """
        import re as _re
        from collections import defaultdict

        if not entries:
            return {}

        grouped: dict = defaultdict(list)
        for e in entries:
            grouped[(e["adapter_kind"], e["resource_kind"])].append(e["metric_key"])

        all_keys = {e["metric_key"] for e in entries}
        policy_id = self.get_default_policy_id()

        # Export ZIP.
        r = self._req(
            "GET", "/api/policies/export",
            params={"id": policy_id},
            headers={"Accept": "application/zip"},
        )
        if r.status_code != 200:
            raise RuntimeError(
                f"Policy export failed ({r.status_code}): {r.text}"
            )

        zip_bytes = r.content
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            xml_names = [n for n in zf.namelist() if n.endswith(".xml")]
            if not xml_names:
                raise RuntimeError("Policy export ZIP contained no XML file")
            xml_name = xml_names[0]
            raw_xml = zf.read(xml_name)
            other_files = {n: zf.read(n) for n in zf.namelist() if n != xml_name}

        for prefix, uri in _re.findall(
            r'xmlns(?::([A-Za-z_][A-Za-z0-9_.-]*))?=["\']([^"\']+)["\']',
            raw_xml.decode("utf-8"),
        ):
            ET.register_namespace(prefix if prefix else "", uri)

        root = ET.fromstring(raw_xml)

        pkg_settings = root.find(".//{*}PackageSettings")
        if pkg_settings is None:
            pkg_settings = root.find(".//PackageSettings")
        if pkg_settings is None:
            policy_elem = root.find(".//{*}Policy")
            if policy_elem is None:
                policy_elem = root.find(".//Policy")
            if policy_elem is None:
                raise RuntimeError(
                    "Policy XML has no <Policy> element -- cannot inject built-in metrics"
                )
            pkg_settings = ET.SubElement(policy_elem, "PackageSettings")

        # Check which keys were already enabled before our edit.
        already_enabled: set = set()
        for block in (
            pkg_settings.findall("{*}Metrics") or pkg_settings.findall("Metrics")
        ):
            for elem in list(block):
                tag = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
                if tag == "Metric":
                    mid = elem.get("id", "")
                    if mid in all_keys and elem.get("enabled", "").lower() == "true":
                        already_enabled.add(mid)

        # Purge stale <Metric> entries for keys being injected.
        for block in (
            pkg_settings.findall("{*}Metrics") or pkg_settings.findall("Metrics")
        ):
            for elem in list(block):
                tag = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
                if tag == "Metric" and elem.get("id", "") in all_keys:
                    block.remove(elem)

        # Inject fresh entries grouped by (adapter_kind, resource_kind).
        for (adapter_kind, resource_kind), metric_keys in grouped.items():
            metrics_block = None
            for candidate in (
                pkg_settings.findall("{*}Metrics") or pkg_settings.findall("Metrics")
            ):
                if (
                    candidate.get("adapterKind") == adapter_kind
                    and candidate.get("resourceKind") == resource_kind
                ):
                    metrics_block = candidate
                    break
            if metrics_block is None:
                metrics_block = ET.SubElement(
                    pkg_settings,
                    "Metrics",
                    {"adapterKind": adapter_kind, "resourceKind": resource_kind},
                )
            for metric_key in metric_keys:
                ET.SubElement(
                    metrics_block,
                    "Metric",
                    {"enabled": "true", "id": metric_key},
                )

        # Serialise and rebuild ZIP.
        edited_xml = ET.tostring(root, encoding="unicode", xml_declaration=False)
        if not edited_xml.startswith("<?xml"):
            edited_xml = '<?xml version="1.0" encoding="UTF-8"?>\n' + edited_xml
        edited_xml_bytes = edited_xml.encode("utf-8")

        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(xml_name, edited_xml_bytes)
            for name, data in other_files.items():
                zf.writestr(name, data)
        zip_out = buf.getvalue()

        # POST rebuilt ZIP.
        saved_ct = self._session.headers.pop("Content-Type", None)
        try:
            r = self._session.post(
                f"{self.base}/api/policies/import",
                params={"forceImport": "true"},
                files={"policy": ("exportedPolicies.zip", zip_out, "application/zip")},
            )
        finally:
            if saved_ct is not None:
                self._session.headers["Content-Type"] = saved_ct
        if r.status_code not in (200, 201, 204):
            raise RuntimeError(
                f"Policy import for built-in metrics failed ({r.status_code}): {r.text}"
            )

        return {key: key in already_enabled for key in all_keys}

    def export_default_policy_xml(self, policy_id: str) -> str:
        """Export a policy and return the raw XML from the ZIP."""
        r = self._req(
            "GET", "/api/policies/export",
            params={"id": policy_id},
            headers={"Accept": "application/zip"},
        )
        if r.status_code != 200:
            raise RuntimeError(
                f"Policy export failed ({r.status_code}): {r.text}")
        with zipfile.ZipFile(io.BytesIO(r.content)) as zf:
            for name in zf.namelist():
                if name.endswith(".xml"):
                    return zf.read(name).decode("utf-8")
        raise RuntimeError("Policy export ZIP contained no XML file")

    def upsert_custom_group(self, payload: dict) -> None:
        name = payload["resourceKey"]["name"]
        r = self._req("GET", "/api/resources/groups",
                      params={"name": name, "pageSize": 100})
        if r.status_code != 200:
            _die(f"Custom group list failed ({r.status_code}): {r.text}")
        existing_id = None
        for g in r.json().get("groups") or []:
            if (g.get("resourceKey") or {}).get("name") == name:
                existing_id = g["id"]
                break
        if existing_id:
            r = self._req("PUT", f"/api/resources/groups/{existing_id}", json=payload)
            if r.status_code == 500:
                # The custom group PUT endpoint sometimes returns 500 even when
                # the update was applied. Verify by fetching the group before
                # treating it as fatal.
                chk = self._req("GET", "/api/resources/groups",
                                params={"name": name, "pageSize": 100})
                found = any(
                    (g.get("resourceKey") or {}).get("name") == name
                    for g in (chk.json().get("groups") or [])
                ) if chk.status_code == 200 else False
                if found:
                    _warn(f"Custom group PUT returned 500 but group exists, treating as success: {name}")
                else:
                    _die(f"Custom group PUT failed ({r.status_code}): {r.text}")
            elif r.status_code not in (200, 201, 204):
                _die(f"Custom group PUT failed ({r.status_code}): {r.text}")
        else:
            r = self._req("POST", "/api/resources/groups", json=payload)
            if r.status_code not in (200, 201):
                _die(f"Custom group POST failed ({r.status_code}): {r.text}")

    # ------------------------------------------------------------------
    # Uninstall helpers
    # ------------------------------------------------------------------

    def find_supermetric_ids(self, names: List[str]) -> Dict[str, str]:
        """Return {name: id} for super metrics matching any of the given names."""
        return self.list_supermetrics_by_name(names)

    def delete_supermetric(self, sm_id: str) -> int:
        """DELETE /api/supermetrics/{id}. Returns HTTP status code."""
        r = self._req("DELETE", f"/api/supermetrics/{sm_id}")
        return r.status_code

    def find_customgroup_ids(self, names: List[str]) -> Dict[str, str]:
        """Return {name: id} for custom groups matching any of the given names."""
        found: Dict[str, str] = {}
        target = set(names)
        page, page_size = 0, 1000
        while True:
            r = self._req("GET", "/api/resources/groups",
                          params={"page": page, "pageSize": page_size})
            if r.status_code != 200:
                _die(f"Custom group list failed ({r.status_code}): {r.text}")
            body = r.json()
            groups = body.get("groups") or []
            for g in groups:
                n = (g.get("resourceKey") or {}).get("name", "")
                if n in target:
                    found[n] = g["id"]
            info = body.get("pageInfo") or {}
            total = info.get("totalCount", len(groups))
            if (page + 1) * page_size >= total or not groups:
                break
            page += 1
        return found

    def delete_customgroup(self, group_id: str) -> int:
        """DELETE /api/resources/groups/{groupId}. Returns HTTP status code."""
        r = self._req("DELETE", f"/api/resources/groups/{group_id}")
        return r.status_code


# ---------------------------------------------------------------------------
# UI session client (dashboards + views delete)
# ---------------------------------------------------------------------------
class UIClient:
    """Minimal UI-session client for dashboard and view delete.

    Authentication flow (three steps):
      1. GET /ui/login.action?vcf=1  -- seeds JSESSIONID
      2. POST /ui/login.action (form creds) -- validates credentials
      3. GET /ui/index.action (no redirect) -- OPS_SESSION with csrfToken

    See knowledge/context/api-surface/dashboard_delete_api.md for full protocol documentation.
    """

    def __init__(self, host: str, user: str, password: str,
                 auth_source: str = "Local", verify_ssl: bool = True):
        self._host = host
        self._user = user
        self._password = password
        # The UI login form expects "localItem"; Suite API uses "Local".
        # Accept the canonical "Local" value and translate here.
        self._auth_source = "localItem" if auth_source == "Local" else auth_source
        self._verify_ssl = verify_ssl
        self._session: Optional[requests.Session] = None
        self._csrf_token: Optional[str] = None
        self._tid = 1

    def login(self) -> None:
        s = _new_session(self._verify_ssl)

        # Step 1: seed JSESSIONID
        s.get(f"https://{self._host}/ui/login.action", params={"vcf": "1"})

        # Step 2: login with credentials
        resp = s.post(
            f"https://{self._host}/ui/login.action",
            data={
                "mainAction": "login",
                "userName": self._user,
                "password": self._password,
                "authSourceId": self._auth_source,
                "authSourceName": "Local Account",
                "authSourceType": "",
                "forceLogin": "false",
                "timezone": "0",
                "languageCode": "us",
            },
        )
        if resp.text.strip() != "ok":
            _die(f"UI authentication failed: {resp.text!r}")

        # Step 3: hit index.action WITHOUT following the 302 redirect.
        # OPS_SESSION cookie is set on the 302 response and cleared if
        # the redirect is followed.
        resp = s.get(
            f"https://{self._host}/ui/index.action",
            allow_redirects=False,
        )
        ops_cookie = resp.cookies.get("OPS_SESSION") or s.cookies.get("OPS_SESSION")
        if not ops_cookie:
            _die("OPS_SESSION cookie not received -- check credentials and auth source")
        try:
            ops_data = json.loads(base64.b64decode(ops_cookie))
        except Exception as exc:
            _die(f"Failed to decode OPS_SESSION cookie: {exc}")
        csrf_token = ops_data.get("csrfToken")
        if not csrf_token:
            _die("csrfToken not found in OPS_SESSION payload")

        self._session = s
        self._csrf_token = csrf_token

    def logout(self) -> None:
        if self._session is None:
            return
        try:
            self._session.get(
                f"https://{self._host}/ui/login.action",
                params={"mainAction": "logout"},
                allow_redirects=False,
            )
        except Exception:
            pass
        finally:
            self._session = None
            self._csrf_token = None

    def list_dashboards(self) -> List[Dict[str, Any]]:
        """Return all dashboards visible to the authenticated user."""
        assert self._session and self._csrf_token
        resp = self._session.post(
            f"https://{self._host}/ui/dashboard.action",
            data={
                "mainAction": "getDashboardList",
                "secureToken": self._csrf_token,
                "currentComponentInfo": "TODO",
                "globalDate": json.dumps({"dateRange": "last6Hour"}),
            },
        )
        resp.raise_for_status()
        return resp.json().get("dashboards") or []

    def delete_dashboards(self, dashboards: List[Tuple[str, str]]) -> None:
        """Delete dashboards by (uuid, name) tuples."""
        assert self._session and self._csrf_token
        tab_ids = [{"tabId": uid, "tabName": name} for uid, name in dashboards]
        resp = self._session.post(
            f"https://{self._host}/ui/dashboard.action",
            data={
                "mainAction": "deleteTab",
                "tabIds": json.dumps(tab_ids),
                "secureToken": self._csrf_token,
                "currentComponentInfo": "TODO",
                "globalDate": json.dumps({"dateRange": "last6Hour"}),
            },
        )
        resp.raise_for_status()

    def _ext_direct_url(self) -> str:
        """Return the Ext.Direct router URL.

        Empirically verified 2026-04-11: /ui/vcops/services/router is the
        correct working URL. The SPA context at
        /vcf-operations/plug/ops/vcops/services/router returns HTTP 400
        because the session JSESSIONID cookie is scoped to /ui, not to the
        /vcf-operations/ path.

        The real fix for the prior "everything returns 500" bug was the
        data shape for deleteView: the old code sent a bare UUID string;
        the correct shape uses viewDefIds with a JSON-stringified [{id,name}]
        array. See knowledge/context/api-surface/dashboard_delete_api.md §2026-04-11 update.
        """
        return f"https://{self._host}/ui/vcops/services/router"

    def list_views(self) -> List[Dict[str, Any]]:
        """List all view definitions via Ext.Direct RPC."""
        assert self._session and self._csrf_token
        tid = self._next_tid()
        resp = self._session.post(
            self._ext_direct_url(),
            json=[{
                "action": "viewServiceController",
                "method": "getGroupedViewDefinitionThumbnails",
                "data": [{"start": 0, "limit": 500}],
                "type": "rpc",
                "tid": tid,
            }],
            headers={"secureToken": self._csrf_token},
        )
        resp.raise_for_status()
        result = resp.json()
        if result[0].get("type") == "exception":
            _die(f"View list failed: {result[0].get('message')}")
        grouped = result[0].get("result") or {}
        views: List[Dict[str, Any]] = []
        # API returns a dict keyed by view type (LIST, IMAGE, etc.),
        # each value is a dict keyed by subject name (HostSystem, etc.),
        # each subject value is a list of view objects.
        if isinstance(grouped, dict):
            for view_type_group in grouped.values():
                if isinstance(view_type_group, dict):
                    for subject_views in view_type_group.values():
                        if isinstance(subject_views, list):
                            views.extend(subject_views)
        return views

    def delete_view(self, view_uuid: str, view_name: str) -> None:
        """Delete a view by UUID + name via Ext.Direct RPC.

        The data shape for deleteView is an array containing one dict whose
        'viewDefIds' value is a JSON-stringified array of {id, name} objects:
            "data": [{"viewDefIds": "[{\"id\":\"...\",\"name\":\"...\"}]"}]
        Both id and name are required. Sending a bare UUID (old shape) causes
        the handler to return type:exception "Internal server error."
        See knowledge/context/api-surface/dashboard_delete_api.md §2026-04-11 update.
        """
        assert self._session and self._csrf_token
        tid = self._next_tid()
        json_payload = json.dumps([{"id": view_uuid, "name": view_name}])
        resp = self._session.post(
            self._ext_direct_url(),
            json=[{
                "action": "viewServiceController",
                "method": "deleteView",
                "data": [{"viewDefIds": json_payload}],
                "type": "rpc",
                "tid": tid,
            }],
            headers={"secureToken": self._csrf_token},
        )
        resp.raise_for_status()
        result = resp.json()
        if result[0].get("type") == "exception":
            raise RuntimeError(f"deleteView {view_uuid!r} failed: {result[0].get('message')}")

    def list_reports(self) -> List[Dict[str, Any]]:
        """List all report definitions via Ext.Direct RPC.

        Uses getReportDefinitionThumbnails. Returns a flat list of report
        dicts, each containing at least 'id' and 'name'. Response structure
        is {"records": [...], "total": N, ...} inside the result field.
        """
        assert self._session and self._csrf_token
        tid = self._next_tid()
        resp = self._session.post(
            self._ext_direct_url(),
            json=[{
                "action": "reportServiceController",
                "method": "getReportDefinitionThumbnails",
                "data": [{
                    "contentFilter": {"isTenant": False},
                    "resourceContext": None,
                    "page": 1,
                    "start": 0,
                    "limit": 500,
                    "sort": [{"property": "creationTime", "direction": "DESC"}],
                }],
                "type": "rpc",
                "tid": tid,
            }],
            headers={"secureToken": self._csrf_token},
        )
        resp.raise_for_status()
        result = resp.json()
        if result[0].get("type") == "exception":
            _die(f"Report list failed: {result[0].get('message')}")
        raw = result[0].get("result") or {}
        # getReportDefinitionThumbnails returns:
        #   {"records": [...], "total": N, "metaData": {...}, "success": true}
        # Walk common shapes in priority order.
        if isinstance(raw, list):
            return raw
        for key in ("records", "data", "items", "reportDefinitions", "reports"):
            if isinstance(raw.get(key), list):
                return raw[key]
        # Fallback: flatten any lists found one level deep
        report_items: List[Dict[str, Any]] = []
        if isinstance(raw, dict):
            for v in raw.values():
                if isinstance(v, list):
                    report_items.extend(v)
        return report_items

    def delete_reports(self, reports: List[Tuple[str, str]]) -> None:
        """Delete report definitions by (uuid, name) tuples via Ext.Direct RPC.

        The data shape for deleteReportDefinitions is a BARE DICT (not an
        array) whose 'reportDefIds' value is a JSON-stringified array of
        {id, name} objects:
            "data": {"reportDefIds": "[{\"id\":\"...\",\"name\":\"...\"}]"}
        This differs from deleteView which wraps data in an array of one dict.
        Success response is {"type":"rpc"} with no "result" key.
        See knowledge/context/api-surface/dashboard_delete_api.md §2026-04-11 update.
        """
        assert self._session and self._csrf_token
        tid = self._next_tid()
        json_payload = json.dumps([{"id": uid, "name": name} for uid, name in reports])
        resp = self._session.post(
            self._ext_direct_url(),
            json=[{
                "action": "reportServiceController",
                "method": "deleteReportDefinitions",
                "data": {"reportDefIds": json_payload},  # BARE DICT, not array
                "type": "rpc",
                "tid": tid,
            }],
            headers={"secureToken": self._csrf_token},
        )
        resp.raise_for_status()
        result = resp.json()
        if result[0].get("type") == "exception":
            raise RuntimeError(
                f"deleteReportDefinitions failed: {result[0].get('message')}"
            )

    def _next_tid(self) -> int:
        tid = self._tid
        self._tid += 1
        return tid


# ---------------------------------------------------------------------------
# Content-zip builders (install mode)
# ---------------------------------------------------------------------------
def _build_sm_zip(supermetrics_dict: dict, marker: str, owner_id: str) -> bytes:
    """Build SM content-zip from a dict keyed by UUID (wire format)."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(marker, owner_id)
        z.writestr("supermetrics.json", json.dumps(supermetrics_dict, indent=2))
        z.writestr(
            "configuration.json",
            json.dumps({"superMetrics": len(supermetrics_dict), "type": "ALL"}, indent=2),
        )
    return buf.getvalue()


def _build_views_inner_zip(xml_text: str) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("content.xml", xml_text)
    return buf.getvalue()


def _build_dashboard_inner_zip(dashboard_json: str) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("dashboard/dashboard.json", dashboard_json)
        for lang in ("", "_es", "_fr", "_ja"):
            z.writestr(f"dashboard/resources/resources{lang}.properties", "")
    return buf.getvalue()


def _build_dashboard_zip(views_xml: str, dashboard_json: str,
                         marker: str, owner_id: str, username: str,
                         n_views: int, n_dashboards: int,
                         dashboard_ids: list) -> bytes:
    """Build combined views+dashboard content-zip with correct wire format."""
    config: dict = {"type": "CUSTOM"}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as outer:
        outer.writestr(marker, owner_id)

        if views_xml:
            outer.writestr("views.zip", _build_views_inner_zip(views_xml))
            config["views"] = n_views

        if dashboard_json:
            outer.writestr(zipfile.ZipInfo("dashboards/"), b"")
            outer.writestr(zipfile.ZipInfo("dashboardsharings/"), b"")

            patched_json = dashboard_json.replace("PLACEHOLDER_USER_ID", owner_id)
            outer.writestr(
                f"dashboards/{owner_id}",
                _build_dashboard_inner_zip(patched_json),
            )
            outer.writestr(
                f"dashboardsharings/{owner_id}",
                json.dumps([
                    {
                        "groupName": "Everyone",
                        "sourceType": "LOCAL",
                        "dashboards": [{"dashboardId": did} for did in dashboard_ids],
                    }
                ]),
            )
            outer.writestr(
                "usermappings.json",
                json.dumps({
                    "sources": [],
                    "users": [{"userName": username, "userId": owner_id}],
                }, indent=2),
            )
            config["dashboards"] = n_dashboards
            config["dashboardsByOwner"] = [{"owner": owner_id, "count": n_dashboards}]

        outer.writestr("configuration.json", json.dumps(config, indent=2))

    return buf.getvalue()


def _extract_dashboard_ids(dashboard_json: str) -> list:
    data = json.loads(dashboard_json)
    return [d["id"] for d in (data.get("dashboards") or []) if d.get("id")]


# Bounds for the content names interpolated into the "NOT updated"
# advisory. That string prints twice (inline WARN plus the ATTENTION
# trailer), so a single pathological name or a bundle carrying dozens of
# objects must not fill the operator's screen. Same echo-safe discipline
# as the doctor's _clip, deliberately re-stated rather than imported:
# this template ships standalone inside every bundle zip.
_ADVISORY_NAME_MAX_CHARS = 120
_ADVISORY_NAMES_MAX = 20


def _bounded_names(names) -> list:
    """Coerce, clip and cap content names bound for an advisory line.

    Shared by _extract_dashboard_names and _extract_view_names so both
    halves of the "the existing X was NOT updated: <names>" sentence
    behave alike.

    The str() coercion is load-bearing, not defensive tidying: the
    advisory is built with ", ".join(...) OUTSIDE any try, so a non-string
    name (JSON permits {"name": 123}) raised TypeError and aborted the
    installer AFTER content had already been imported, leaving a partial
    install. A decoration helper must never be able to do that.

    Carries its own try for the same reason. Both current callers are
    already safe (one calls inside its try, the other pre-filters), so
    this is unreachable today, but this is now a SHARED helper: a third
    caller passing a non-iterable, or an element whose __str__ raises,
    would otherwise reintroduce exactly the crash class above.
    """
    out: list = []
    try:
        for name in names:
            if not isinstance(name, str):
                name = str(name)
            if len(name) > _ADVISORY_NAME_MAX_CHARS:
                name = name[:_ADVISORY_NAME_MAX_CHARS] + "..."
            out.append(name)
    except Exception:  # noqa: BLE001
        return []
    if len(out) > _ADVISORY_NAMES_MAX:
        extra = len(out) - _ADVISORY_NAMES_MAX
        out = out[:_ADVISORY_NAMES_MAX] + [f"and {extra} more"]
    return out


def _extract_dashboard_names(dashboard_json: str) -> list:
    """Names of the dashboards in a rendered dashboard.json, best effort.

    Same never-raise contract as _extract_view_names, and deliberately
    the same bare `except Exception` as that sibling rather than a
    narrower tuple. `except (TypeError, ValueError)` was not wide enough:
    json.loads raises RecursionError on deeply nested input, and
    RecursionError subclasses RuntimeError, not ValueError, so it escaped
    to the post-import call site. Every caller of this function runs
    AFTER content has been imported, so an escaping exception leaves a
    partial install; that consequence, not the odds, sets the width.
    """
    try:
        data = json.loads(dashboard_json)
        # json.loads happily returns a list, a string or a number, none
        # of which have .get; that AttributeError is not a ValueError.
        if not isinstance(data, dict):
            return []
        entries = data.get("dashboards") or []
        # Without this, a string value iterates character by character
        # and yields one "?" per character: no exception, but the
        # operator reads "NOT updated: ?, ?, ?, ?".
        if not isinstance(entries, list):
            return []
        names = [
            (d.get("name") or d.get("id") or "?") if isinstance(d, dict) else "?"
            for d in entries
        ]
    except Exception:  # noqa: BLE001
        return []
    return _bounded_names(names)


def _extract_view_names(views_xml) -> list:
    """Titles of the views in a rendered views_content.xml, best effort.

    Parses with xml.etree.ElementTree (stdlib) exactly the way
    vcfcf_packaging/audit.py reads view titles: walk every ViewDef, take
    its <Title> child text, fall back to a name attribute. The renderer
    emits <Title> once per ViewDef and nowhere else, so extraction is 1:1
    with views.

    A real parse buys three things the previous regex did not have: it is
    linear (the regex rescanned to end-of-string from every unclosed
    <Title>), it ignores attributes on <Title> (the pre-DEF-018
    localizationKey form extracted nothing), and it hands back decoded
    text, so a view named "CPU & Memory" prints that way instead of
    "CPU &amp; Memory" beside the unescaped dashboard names.

    Never raises: this is a message-decoration helper on the install
    path, so a malformed document (ParseError), a non-str argument, or
    undecodable text degrades to "no names" rather than failing an
    install that otherwise succeeded.
    """
    names: list = []
    try:
        if not views_xml:
            return []
        root = ET.fromstring(views_xml)
        for viewdef in root.iter("ViewDef"):
            title_el = viewdef.find("Title")
            name = (title_el.text or "").strip() if title_el is not None else ""
            if not name:
                name = (viewdef.get("name") or "").strip()
            if not name:
                name = "unnamed view"
            names.append(name)
    except Exception:  # noqa: BLE001
        return []
    return _bounded_names(names)


def _all_skipped_summaries(result: dict, content_types) -> dict:
    """{contentType: (imported, skipped)} for summaries that imported
    nothing while skipping something.

    A FINISHED import with imported=0/skipped=N left the instance
    unchanged, so it must not be reported as a clean install.
    """
    flagged = {}
    for entry in (result or {}).get("operationSummaries") or []:
        ct = entry.get("contentType") or "?"
        if content_types and ct not in content_types:
            continue
        try:
            imported = int(entry.get("imported") or 0)
            skipped = int(entry.get("skipped") or 0)
        except (TypeError, ValueError):
            continue
        if imported == 0 and skipped > 0:
            flagged[ct] = (imported, skipped)
    return flagged


#: The factory's vcfcf_dashboards.client.SHORTFALL_SEVERITY, re-stated (this
#: template ships standalone; a parity test pins it). Only DASHBOARDS, the
#: measured type, is an error; every other type's shortfall is a warning
#: that changes no exit code, because its `total` is not verified.
_SHORTFALL_SEVERITY = {"DASHBOARDS": "error"}


def _whole(value):
    """Same rule as vcfcf_dashboards.client._whole: int (not bool) or ASCII
    digit string; None is 0; anything else is False (not a count)."""
    if value is None:
        return 0
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return value if value >= 0 else False
    if isinstance(value, str) and value and all("0" <= c <= "9" for c in value):
        return int(value)
    return False


def _import_count_findings(result: dict, content_types=None) -> list:
    """[(severity, contentType, message)] for a FINISHED import result; the
    factory's import_count_findings re-stated (parity test). On 8.18.7 and
    9.0.2 a dashboard with a widget type the build does not know aborts the
    whole dashboards batch, and the task still reports FINISHED with
    imported=skipped=failed=0: counters short of total are the only sign."""
    if not isinstance(result, dict) or result.get("state") != "FINISHED":
        return []
    found = {}
    for entry in result.get("operationSummaries") or []:
        if not isinstance(entry, dict):
            continue
        ct = entry.get("contentType") or "?"
        if not isinstance(ct, str):
            ct = "?"
        if content_types and ct not in content_types:
            continue
        if entry.get("total") is None:
            continue
        counts = [_whole(entry.get(k)) for k in ("total", "imported", "skipped", "failed")]
        if any(c is False for c in counts):
            found[ct] = ("warning", _import_uninterpretable_message(ct))
            continue
        total, imported, skipped, failed = counts
        if imported + skipped + failed < total:
            found[ct] = (_SHORTFALL_SEVERITY.get(ct, "warning"),
                         _import_shortfall_message(ct, tuple(counts)))
    return [(sev, ct, msg) for ct, (sev, msg) in sorted(found.items())]


def _import_shortfall_message(content_type: str, counts) -> str:
    """Same text as vcfcf_dashboards.client.import_shortfall_message."""
    total, imported, skipped, failed = counts
    missing = total - imported - skipped - failed
    head = (
        f"{content_type}: the import accounted for {total - missing} of "
        f"{total} (imported={imported} skipped={skipped} failed={failed}); "
        f"{missing} were neither imported, skipped nor failed, and the task "
        f"still reported FINISHED."
    )
    if content_type == "DASHBOARDS":
        return head + (
            " The likely cause is a widget type this instance's version "
            "cannot import (for example Section, measured failing on 8.18.7 "
            "and 9.0.2): one such dashboard makes the importer discard every "
            "dashboard in the same import, and view-bridge.log shows "
            "'restoreData failed to import Dashboards'. Check which dashboards "
            "exist on the instance."
        )
    return head + (
        f" What total counts for {content_type} has not been verified (no "
        f"healthy {content_type} import result with a total is recorded), so "
        f"this is a warning, not a failure. Check on the instance which "
        f"objects exist, and report it with the import envelope."
    )


def _import_uninterpretable_message(content_type: str) -> str:
    """Same text as vcfcf_dashboards.client.import_uninterpretable_message."""
    return (
        f"{content_type}: the import result carries a total but its counters "
        f"are not all whole numbers, so whether everything imported cannot be "
        f"told from it. Check on the instance which objects exist, and report "
        f"it with the import envelope."
    )


#: Prefix of an error-severity shortfall in ctx["warnings"]; the run summary
#: keys on it to end on "not imported" instead of "refresh after 5 minutes".
_SHORTFALL_PREFIX = "IMPORT SHORTFALL: "


def _lost_import_lines(lost) -> list:
    """The closing lines of a run with error-severity shortfalls: one per
    content type, saying it was not imported and why."""
    lines = []
    for w in lost:
        ct = w[len(_SHORTFALL_PREFIX):].split(":", 1)[0]
        if ct == "DASHBOARDS":
            why = ("the import accounted for fewer dashboards than it carried, "
                   "most likely because one of them uses a widget type this VCF "
                   "Operations version cannot import (see IMPORT SHORTFALL above). "
                   "Waiting or refreshing will not bring them back.")
        else:
            why = ("the import accounted for fewer objects than it carried "
                   "(see IMPORT SHORTFALL above).")
        lines.append(f"ERROR: {ct} were not imported: {why}")
    if lines:
        lines.insert(0, "")
    return lines


def _record_import_shortfalls(ctx: Dict, result: dict) -> list:
    """Print every finding. Errors print as ERROR and go to ctx["warnings"]
    (exit 2); warnings print as WARN and change nothing. Returns the
    content types with an error."""
    errors = []
    for sev, ct, msg in _import_count_findings(result):
        if sev == "error":
            print(f"  ERROR  {_SHORTFALL_PREFIX}{msg}")
            ctx["warnings"].append(_SHORTFALL_PREFIX + msg)
            errors.append(ct)
        else:
            _warn(_SHORTFALL_PREFIX + msg)
    return errors


# Widget-type floors and the sentence for what a dashboard carrying one costs:
# the factory's vcfcf_core.dashboards.widget_versions (WIDGET_TYPE_MIN_OPS_VERSION
# entries with a floor, WIDGET_TYPE_REFUSE_BELOW_OPS_VERSION,
# IMPORT_LOSS_SENTENCE), re-stated; a parity test pins them. Refused below
# the measured-failing version, warned on between it and the proven floor.
_WIDGET_TYPE_FLOORS = {"Section": (9, 1, 1)}
_WIDGET_TYPE_REFUSE_BELOW = {"Section": (9, 1, 0)}
_IMPORT_LOSS_SENTENCE = (
    "the importer then aborts on that dashboard: a content import (sync, "
    "bundle install) loses EVERY dashboard in the same import (measured with "
    "one owner, which every factory import has), a pak install every "
    "dashboard in the same content/dashboards directory, and the task still "
    "reports FINISHED with nothing failed"
)
_VERSION_UNREADABLE_NOTE = (
    "could not read the instance version (GET /api/versions/current), "
    "so the widget-type floors were not checked before import; a "
    "dashboard with a widget type this build cannot import loses every "
    "dashboard in the import, which the import result check reports."
)
#: Same pattern as widget_versions.RELEASE_NAME_VERSION_RE.
_RELEASE_NAME_VERSION_RE = re.compile(
    r"Operations[ \t\r\n]+([0-9]+(?:\.[0-9]+)+)(?=[ \t\r\n]|\Z)"
)


def _version_tuple(value) -> tuple:
    parts = [int(p) for p in (value if isinstance(value, tuple) else str(value).split("."))]
    while len(parts) > 1 and parts[-1] == 0:
        parts.pop()
    return tuple(parts)


def _format_version(v) -> str:
    parts = list(v) + [0] * (3 - len(v))
    return ".".join(str(p) for p in parts)


def _parse_release_name(release_name):
    """Same rule as widget_versions.parse_release_name. Never raises."""
    if not isinstance(release_name, str):
        return None
    m = _RELEASE_NAME_VERSION_RE.search(release_name)
    return _version_tuple(m.group(1)) if m else None


def _dashboard_widget_pairs(dashboard_json: str) -> list:
    """[(name, [(widget id, type), ...])] from a rendered dashboard.json.
    Never raises (an unreadable file yields [])."""
    try:
        data = json.loads(dashboard_json)
        out = []
        for d in (data.get("dashboards") or []) if isinstance(data, dict) else []:
            if not isinstance(d, dict):
                continue
            widgets = [
                (str(w.get("id") or "?"), str(w.get("type") or ""))
                for w in (d.get("widgets") or []) if isinstance(w, dict)
            ]
            out.append((str(d.get("name") or d.get("id") or "?"), widgets))
        return out
    except Exception:  # noqa: BLE001
        return []


def _import_check(dashboards, instance_version):
    """Same rule and texts as widget_versions.import_check: (refusal, warning)."""
    have = _version_tuple(instance_version)
    refused, unverified = [], []
    refused_types, unverified_types = {}, {}
    for name, widgets in dashboards:
        bad, unsure = [], []
        for local_id, wtype in widgets:
            floor = _WIDGET_TYPE_FLOORS.get(wtype)
            if floor is None or have >= _version_tuple(floor):
                continue
            floor = _version_tuple(floor)
            below = _WIDGET_TYPE_REFUSE_BELOW.get(wtype)
            if below is not None and have < _version_tuple(below):
                refused_types[wtype] = (_version_tuple(below), floor)
                bad.append(f"{local_id} ({wtype})")
            else:
                unverified_types[wtype] = (_version_tuple(below) if below else floor, floor)
                unsure.append(f"{local_id} ({wtype})")
        if bad:
            refused.append(f"'{name}' (widget(s) {', '.join(bad)})")
        if unsure:
            unverified.append(f"'{name}' (widget(s) {', '.join(unsure)})")
    have_s = _format_version(have)
    if refused:
        why = ", ".join(
            f"{t} is measured not to import below {_format_version(b)} and "
            f"proven to import from {_format_version(f)}"
            for t, (b, f) in sorted(refused_types.items())
        )
        top = max(f for _b, f in refused_types.values())
        return (
            f"refused before import: this instance is VCF Operations {have_s}; "
            f"{why}. Dashboards carrying it: {'; '.join(refused)}. On this "
            f"build {_IMPORT_LOSS_SENTENCE}, so the import was not sent. Remove "
            f"those widgets or install on VCF Operations "
            f"{_format_version(top)} or later (issue #199).",
            None,
        )
    if unverified:
        why = ", ".join(
            f"{t} is proven to import from {_format_version(f)} and measured "
            f"not to import below {_format_version(b)}"
            for t, (b, f) in sorted(unverified_types.items())
        )
        return (
            None,
            f"this instance is VCF Operations {have_s}, which is unverified: "
            f"{why}. Dashboards carrying it: {'; '.join(unverified)}. Importing "
            f"anyway; if this build cannot import it, {_IMPORT_LOSS_SENTENCE}, "
            f"and the import result check reports the loss (issue #199).",
        )
    return None, None


def _preflight_widget_floors(client, bundles: List[Dict]) -> None:
    """Refuse the install, before anything is imported, when the instance's
    version is measured not to import a widget type a selected bundle's
    dashboards use. An unmeasured or unreadable version is a WARN: the
    import goes ahead and the shortfall check reports a loss."""
    pairs = []
    for bundle in bundles:
        content = (bundle.get("manifest") or {}).get("content") or {}
        entry = content.get("dashboards")
        if not isinstance(entry, dict) or not entry.get("file"):
            continue
        try:
            text = (Path(bundle["dir"]) / entry["file"]).read_text(encoding="utf-8")
        except OSError:
            continue
        pairs.extend(_dashboard_widget_pairs(text))
    if not any(_WIDGET_TYPE_FLOORS.get(t) for _n, ws in pairs for _i, t in ws):
        return
    version = client.get_ops_version()
    if version is None:
        _warn(_VERSION_UNREADABLE_NOTE)
        return
    refusal, warning = _import_check(pairs, version)
    if refusal:
        _die(refusal)
    if warning:
        _warn(warning)


# ---------------------------------------------------------------------------
# Post-import dashboard materialization check (issue #244)
#
# A FINISHED dashboard import only covers phase 1: the record is written,
# and each widget's settings are resolved later by a background pass. A
# dashboard waiting on an adapter that is not installed never finishes.
# This is the factory's vcfcf_core.dashboards.materialization classifier
# and the export reader from vcfcf_core.extractor, deliberately re-stated
# rather than imported: this template ships standalone inside every bundle
# zip. tests/test_install_materialization.py pins that the two agree on
# every state and every report sentence.
# ---------------------------------------------------------------------------
_MAT_COMPLETE = "complete"
_MAT_SETTLING = "settling"
_MAT_INCOMPLETE = "incomplete"
_MAT_STALLED = "stalled"
_MAT_ABSENT = "absent"

#: Same default, cap and environment override as the factory CLI.
_MAT_WAIT_DEFAULT_S = 180
_MAT_WAIT_MAX_S = 900
_MAT_WAIT_ENV = "VCFCF_MATERIALIZATION_WAIT_S"


def _mat_wait(requested=None) -> int:
    value = requested
    if value is None:
        raw = os.environ.get(_MAT_WAIT_ENV, "").strip()
        if raw:
            try:
                value = int(raw)
            except ValueError:
                value = None
    if value is None:
        value = _MAT_WAIT_DEFAULT_S
    return max(0, min(int(value), _MAT_WAIT_MAX_S))


def _mat_dashboards_from_export_zip(outer_zip: bytes) -> list:
    """Dashboard dicts from a DASHBOARDS export (one inner zip per owner)."""
    result: list = []
    try:
        with zipfile.ZipFile(io.BytesIO(outer_zip)) as zf:
            for name in zf.namelist():
                if not name.startswith("dashboards/") or name.endswith("/"):
                    continue
                try:
                    with zipfile.ZipFile(io.BytesIO(zf.read(name))) as inner:
                        if "dashboard/dashboard.json" not in inner.namelist():
                            continue
                        dj = json.loads(inner.read("dashboard/dashboard.json"))
                except Exception:  # noqa: BLE001
                    continue
                for dash in (dj.get("dashboards") or []):
                    result.append(dict(dash))
    except Exception as e:  # noqa: BLE001
        raise ValueError(f"failed to parse dashboard export zip: {e}") from e
    return result


def _mat_pending_resources(dashboard: dict) -> list:
    entry_keys = dashboard.get("entryKeys")
    if not isinstance(entry_keys, dict):
        return []
    names: list = []
    for item in entry_keys.get("resource") or []:
        if isinstance(item, dict):
            n = str(item.get("name") or "").strip()
            if n and n not in names:
                names.append(n)
    return names


def _mat_pending_kinds(dashboard: dict) -> list:
    entry_keys = dashboard.get("entryKeys")
    if not isinstance(entry_keys, dict):
        return []
    kinds = set()
    for value in entry_keys.values():
        if not isinstance(value, list):
            continue
        for item in value:
            if isinstance(item, dict):
                ak = str(item.get("adapterKindKey") or "").strip()
                if ak:
                    kinds.add(ak)
    return sorted(kinds)


def _mat_is_incomplete(dashboard: dict) -> bool:
    return dashboard.get("entryKeys") is not None or dashboard.get("importComplete") is False


def _mat_classify(exported, wanted: Dict[str, str], installed_kinds) -> list:
    """One status dict per (id -> name) in ``wanted``; installed_kinds None
    means the adapter kinds could not be read (never stalled on a guess)."""
    by_id = {}
    for d in exported:
        did = str(d.get("id") or "").strip().lower()
        if did:
            by_id[did] = d
    installed = {str(k) for k in installed_kinds} if installed_kinds is not None else None
    out: list = []
    for raw_id, name in wanted.items():
        did = str(raw_id).strip().lower()
        st = {"id": did, "name": name, "state": _MAT_COMPLETE, "pending": [],
              "missing": [], "resources": [], "after": 0,
              "kinds_known": installed is not None}
        d = by_id.get(did)
        if d is None:
            st["state"] = _MAT_ABSENT
        elif _mat_is_incomplete(d):
            st["pending"] = _mat_pending_kinds(d)
            st["missing"] = [k for k in st["pending"]
                             if installed is not None and k not in installed]
            st["resources"] = _mat_pending_resources(d)
            st["state"] = _MAT_STALLED if st["missing"] else _MAT_SETTLING
        out.append(st)
    return out


def _mat_finalize(statuses: list, after: int) -> list:
    for st in statuses:
        st["after"] = int(after)
        if st["state"] == _MAT_SETTLING:
            st["state"] = _MAT_INCOMPLETE
    return statuses


def _mat_quoted(names) -> str:
    return ", ".join(f"'{n}'" for n in names)


def _mat_describe(st: dict) -> str:
    """Same sentences as vcfcf_core.dashboards.materialization.describe_status."""
    resources = (
        f" It also binds the resources {_mat_quoted(st['resources'])}."
        if st["resources"] else ""
    )
    if st["state"] == _MAT_STALLED:
        kinds = ", ".join(st["missing"])
        verb = "is" if len(st["missing"]) == 1 else "are"
        return (
            f"dashboard '{st['name']}' is installed but cannot finish "
            f"building: it is waiting on {kinds}, which {verb} not installed "
            f"on this instance. Its widgets that use those resource kinds "
            f"stay empty until the adapter is installed; re-importing does "
            f"not help.{resources}"
        )
    if st["state"] in (_MAT_INCOMPLETE, _MAT_SETTLING):
        kinds = ", ".join(st["pending"]) or "(none named)"
        res = (
            f" and the resources {_mat_quoted(st['resources'])}"
            if st["resources"] else ""
        )
        installed = (
            "Every adapter kind is installed, so it may still finish"
            if st["kinds_known"] else
            "The installed adapter kinds could not be read, so a missing "
            "adapter is not ruled out; it may still finish"
        )
        return (
            f"dashboard '{st['name']}' had not finished building "
            f"{st['after']} s after the import. It waits on the "
            f"adapter kinds {kinds}{res}. {installed} (the background pass "
            f"can take about 20 minutes; opening it once in the UI is "
            f"faster), but it does not always: a factory dashboard stayed "
            f"incomplete for 19 days with every adapter installed. If it is "
            f"still incomplete later, check that the named resources exist "
            f"on this instance."
        )
    if st["state"] == _MAT_ABSENT:
        return (
            f"dashboard '{st['name']}' ({st['id']}) was in the import but is "
            f"not on the instance afterwards. The importer can drop a whole "
            f"dashboard silently (for example a widget type this Ops build "
            f"lacks); check the instance."
        )
    return ""


def _extract_dashboard_id_names(dashboard_json: str) -> List[Tuple[str, str]]:
    """(id, name) per dashboard in a rendered dashboard.json, best effort.

    The name drops the ``namePath`` folder prefix. Never raises: it runs
    after the import, where an exception would leave a partial install.
    """
    try:
        data = json.loads(dashboard_json)
        if not isinstance(data, dict) or not isinstance(data.get("dashboards"), list):
            return []
        out: List[Tuple[str, str]] = []
        for d in data["dashboards"]:
            if not isinstance(d, dict) or not d.get("id"):
                continue
            name = str(d.get("name") or d["id"])
            path = str(d.get("namePath") or "")
            if path and name.startswith(path + "/"):
                name = name[len(path) + 1:]
            if len(name) > _ADVISORY_NAME_MAX_CHARS:
                name = name[:_ADVISORY_NAME_MAX_CHARS] + "..."
            out.append((str(d["id"]), name))
        return out
    except Exception:  # noqa: BLE001
        return []


def _check_materialization(client: "Client", dashboards: List[Tuple[str, str]],
                           wait_s: int, _sleep=time.sleep) -> List[dict]:
    """Final status per imported dashboard: one export, at most one re-check.

    Raises RuntimeError when the first export fails; a failed re-check or
    adapter-kind read degrades (first read stands, or "not ruled out").
    """
    wanted = {i: n for i, n in dashboards}
    ids = {str(i).lower() for i in wanted}
    kinds_cache: Dict[str, Any] = {}

    def _read() -> list:
        try:
            exported = _mat_dashboards_from_export_zip(client.export_dashboards_zip())
        except ValueError as e:
            raise RuntimeError(str(e)) from e
        if "kinds" not in kinds_cache and any(
            _mat_is_incomplete(d) for d in exported
            if str(d.get("id") or "").lower() in ids
        ):
            try:
                kinds_cache["kinds"] = client.list_adapter_kind_keys()
            except Exception:  # noqa: BLE001
                kinds_cache["kinds"] = None
        return _mat_classify(exported, wanted, kinds_cache.get("kinds"))

    statuses = _read()
    settling = [s for s in statuses if s["state"] == _MAT_SETTLING]
    if not settling or wait_s <= 0:
        return _mat_finalize(statuses, 0)
    print(f"MATERIALIZATION WAIT: {len(settling)} dashboard(s) still building; "
          f"re-checking once in {wait_s} s", flush=True)
    _sleep(wait_s)
    try:
        statuses = _read()
    except Exception:  # noqa: BLE001  the re-check is best effort
        return _mat_finalize(statuses, 0)
    return _mat_finalize(statuses, wait_s)


def _report_materialization(client: "Client", dashboards: List[Tuple[str, str]],
                            args: argparse.Namespace) -> Tuple[List[str], List[str]]:
    """Run the check and print its lines. Returns (warnings, notes).

    ``warnings`` (STALLED: waiting on an adapter that is not installed)
    fail the install (exit 2). ``notes`` (INCOMPLETE, ABSENT, UNCHECKED)
    do not, but they print in the end-of-run attention list.
    """
    if getattr(args, "skip_materialization_check", False) or not dashboards:
        return [], []
    try:
        statuses = _check_materialization(
            client, dashboards, _mat_wait(getattr(args, "materialization_wait", None))
        )
    except Exception as e:  # noqa: BLE001  advisory check
        line = (f"MATERIALIZATION UNCHECKED: could not check whether the "
                f"imported dashboards finished building: {e}")
        print(f"WARNING: {line}")
        return [], [line]
    warnings: List[str] = []
    notes: List[str] = []
    done = sum(1 for st in statuses if st["state"] == _MAT_COMPLETE)
    if done:
        print(f"MATERIALIZATION OK: {done} of {len(statuses)} dashboard(s) finished building")
    for st in statuses:
        if st["state"] == _MAT_COMPLETE:
            continue
        line = f"MATERIALIZATION {st['state'].upper()}: {_mat_describe(st)}"
        print(f"WARNING: {line}")
        (warnings if st["state"] == _MAT_STALLED else notes).append(line)
    return warnings, notes


# ---------------------------------------------------------------------------
# Interactive credential prompts (shared by install and uninstall)
# ---------------------------------------------------------------------------
def _prompt_credentials(args: argparse.Namespace, mode: str) -> tuple:
    """Resolve host, user, auth_source, password, and skip_ssl.

    Priority order: CLI arg > env var > interactive prompt.
    Returns (host, user, auth_source, password, skip_ssl) as plain strings/bool.
    """
    print()
    print(f"VCF Content Factory -- {mode}")
    print("Press Enter to accept [defaults] shown in brackets.")
    print()

    host = args.host
    if not host:
        host = input("VCF Operations host: ").strip()
        if not host:
            _die("Host is required.")

    # Prompt for SSL verification only when neither --skip-ssl-verify nor
    # VCFOPS_VERIFY_SSL=false was supplied (args.skip_ssl_verify already
    # merges both sources, so False here means neither was set).
    skip_ssl = args.skip_ssl_verify
    if not skip_ssl:
        ssl_ans = input("Verify SSL certificate? [Y/n]: ").strip()
        if ssl_ans.lower() in ("n", "no"):
            skip_ssl = True

    user = args.user
    if not user:
        user = input("Username [admin]: ").strip() or "admin"

    # Auth-source support contract (see README_framework.md "Authentication"):
    # Supported: Local (recommended), vCenter SSO (VC/VC_GROUP), Active Directory
    # (UPN form), LDAP (per spec; untested by us).  Not supported: VIDB ("VCF SSO")
    # and VIDM (Workspace ONE Access), both are federated SSO sources that refuse
    # programmatic password grants.  Use a Local service account for those deployments.
    auth_source_raw = args.auth_source
    if not auth_source_raw:
        auth_source_raw = input(
            "Auth source name (or 'local'). Type 'local' for local accounts;"
            " for non-local sources, type the auth-source name as configured"
            " in VCF Operations (e.g. your vCenter SSO source, AD source, or"
            " LDAP source). VIDB and VIDM are not supported -- use a local"
            " account. [local]: "
        ).strip()
    auth_source = _resolve_auth_source(auth_source_raw)

    password = args.password
    if not password:
        password = getpass.getpass("Password: ")
        if not password:
            _die("Password is required.")

    return host, user, auth_source, password, skip_ssl


# ---------------------------------------------------------------------------
# Content type registry
#
# Each entry describes one content type.  The registry drives BOTH install and
# uninstall iteration, replacing the previous hard-coded if/elif chains.
#
# Adding a new content type (e.g. "symptoms") means adding a single entry
# here, the install/uninstall loops below require no changes.
#
# Registry entry keys:
#   content_type   str   key in bundle.json content map (e.g. "supermetrics")
#   manifest_key   str   same as content_type; key in manifest["content"]
#   install_fn     callable(ctx) -> None   runs the install step
#   uninstall_fn   callable(ctx) -> None  runs the uninstall step
#   install_label  str   human-readable step label for install
#   uninstall_label str  human-readable step label for uninstall
#   install_order  number  sorted numerically, lower runs first (install)
#   uninstall_order number sorted numerically, lower runs first (uninstall = reverse install order)
#   needs_ui       bool  True if this type requires UIClient
#
# Detection predicate (install): manifest["content"].get(manifest_key) exists
#   AND its file resolves on disk under bundle_dir.
# Detection predicate (uninstall): manifest["content"].get(content_type) has
#   items with names.
#
# The "ctx" object passed to each function is a plain dict with:
#   client        Client            authenticated Suite API client
#   ui_client     UIClient | None   authenticated UI session client (or None)
#   marker        str               instance marker filename
#   owner_id      str               current user UUID
#   args          argparse.Namespace
#   warnings      List[str]         accumulate WARN strings here
#   bundle_dir    Path              resolved bundle directory
#   manifest      dict              the bundle's manifest (bundle.json)
# ---------------------------------------------------------------------------

def _install_supermetrics(ctx: Dict) -> None:
    bundle_dir = ctx["bundle_dir"]
    manifest = ctx["manifest"]
    sm_file = bundle_dir / manifest["content"]["supermetrics"]["file"]
    sm_dict = _load_json_from_path(sm_file)
    sm_zip = _build_sm_zip(sm_dict, ctx["marker"], ctx["owner_id"])
    result = ctx["client"].import_content_zip(sm_zip, "super metrics") or {}

    # Ghost-state recovery: the content-zip importer will "skip" an SM that
    # already exists in the DB but failed to fully register in the internal SM
    # catalog (e.g. from a previous partial import).  Such SMs are queryable by
    # GET /{id} but absent from the list API and invisible to the assign endpoint,
    # so a subsequent enable call returns 404.  A second import re-registers the
    # SM fully.  Detect the all-skipped signal and retry once automatically.
    summaries = result.get("operationSummaries") or []
    sm_summaries = [s for s in summaries if s.get("contentType") == "SUPER_METRICS"]
    if sm_summaries:
        total_imported = sum(int(s.get("imported") or 0) for s in sm_summaries)
        total_skipped = sum(int(s.get("skipped") or 0) for s in sm_summaries)
        if total_imported == 0 and total_skipped > 0:
            print(f"    [ghost-state recovery] all {total_skipped} SM(s) skipped on first "
                  f"import, retrying to re-register in SM catalog...")
            result = ctx["client"].import_content_zip(sm_zip, "super metrics (retry)") or {}

    if _record_import_shortfalls(ctx, result):
        return
    _ok(f"Imported {len(sm_dict)} super metric(s)")


def _install_dashboards(ctx: Dict) -> None:
    bundle_dir = ctx["bundle_dir"]
    manifest = ctx["manifest"]
    dash_file = bundle_dir / manifest["content"]["dashboards"]["file"]
    dash_json = dash_file.read_text(encoding="utf-8")

    # Views XML (in same bundle content dir, via views manifest key if present)
    views_xml = ""
    if "views" in manifest.get("content", {}):
        views_file = bundle_dir / manifest["content"]["views"]["file"]
        if views_file.exists():
            views_xml = views_file.read_text(encoding="utf-8")

    owner_id = ctx["owner_id"]
    dash_ids = _extract_dashboard_ids(dash_json.replace("PLACEHOLDER_USER_ID", owner_id))
    n_views = 1 if views_xml else 0
    dash_zip = _build_dashboard_zip(
        views_xml, dash_json, ctx["marker"], owner_id, ctx["username"],
        n_views=n_views, n_dashboards=1, dashboard_ids=dash_ids,
    )
    result = ctx["client"].import_content_zip(dash_zip, "dashboard + view") or {}

    # A FINISHED import that imported nothing and skipped everything did
    # not put this run's content on the instance (the dashboard may be the
    # old one, or absent). Previously only the top-level state was consulted, so this was
    # reported as a clean install.
    #
    # Attribution is PER CONTENT TYPE. This zip always carries two of
    # them, so flagging the dashboard because the co-shipped view was
    # skipped (or vice versa) would be a false statement contradicted by
    # the same envelope. Each type gets its own line, and the type that
    # imported normally still gets its success line.
    flagged = _all_skipped_summaries(result, ("DASHBOARDS", "VIEW_DEFINITIONS"))
    # Counters short of total are an error (exit 2): a dashboards batch lost
    # to an unknown widget type reports imported=skipped=failed=0, which the
    # all-skipped advisory below does not see.
    short = _record_import_shortfalls(ctx, result)
    dash_names = _extract_dashboard_names(
        dash_json.replace("PLACEHOLDER_USER_ID", owner_id)
    )
    # Not "the existing dashboard was NOT updated": under the owner-mapping
    # cause the dashboard was never created, and this import sends
    # force=true, so the create-only cause does not apply. Same text as the
    # factory's vcfcf_dashboards.client.skipped_import_advice and install.ps1.
    dash_skip_tail = " " + (
        "This import sent force=true, so the create-only cause "
        "(force=false, which leaves an existing dashboard as it was) does "
        "not apply. The one demonstrated cause under force=true is an owner"
        " in usermappings.json that maps to no user on the target; the "
        "dashboard was then never created. Look in view-bridge.log for "
        "'restoreData failed to map Dashboard. File: <ownerId>' and check "
        "whether the dashboard exists on the instance. Without that log "
        "line the skip is unexplained: report it with the import envelope."
    )
    view_skip_tail = " " + (
        "This import sent force=true, so the create-only cause "
        "(force=false, which leaves an existing view as it was) does not "
        "apply, and an unmapped owner skips dashboards, not views. A view "
        "skip under force=true is unexplained: check whether the view "
        "exists on the instance and holds this version, and report the skip"
        " with the import envelope."
    )

    if "DASHBOARDS" not in flagged or "DASHBOARDS" in short:
        # Post-import materialization check (#244) runs once at the end of
        # the run. A dashboard the import skipped is not what this run put
        # on the instance, so it is not checked (same rule as the factory).
        # After a shortfall it runs: it is the by-id existence check that
        # names the absent dashboards.
        ctx.setdefault("imported_dashboards", []).extend(
            _extract_dashboard_id_names(dash_json.replace("PLACEHOLDER_USER_ID", owner_id))
        )

    if "DASHBOARDS" in flagged:
        imp, skp = flagged["DASHBOARDS"]
        advisory = (
            f"Import changed no dashboards (DASHBOARDS imported={imp} "
            f"skipped={skp}): "
            f"{', '.join(dash_names) if dash_names else 'dashboard'}."
            + dash_skip_tail
        )
        _warn(advisory)
        ctx.setdefault("advisories", []).append(advisory)
    elif "DASHBOARDS" not in short:
        _ok("Imported 1 dashboard")

    if n_views and "VIEW_DEFINITIONS" not in short:
        if "VIEW_DEFINITIONS" in flagged:
            imp, skp = flagged["VIEW_DEFINITIONS"]
            view_names = _extract_view_names(views_xml)
            named = ", ".join(view_names) if view_names else "view(s)"
            advisory = (
                f"Import changed no views (VIEW_DEFINITIONS imported={imp} "
                f"skipped={skp}): "
                f"{named}." + view_skip_tail
            )
            _warn(advisory)
            ctx.setdefault("advisories", []).append(advisory)
        else:
            _ok(f"Imported {n_views} view(s)")

    # Deliberately NOT appended to ctx["warnings"]: that list drives
    # sys.exit(2), and this class must not fail an install that genuinely
    # succeeded. It goes to ctx["advisories"] instead, which prints as a
    # trailer in BOTH summary branches so the operator's last line is
    # never an unqualified "all successful" over a WARN saying content
    # was not updated.


def _install_sm_enable(ctx: Dict) -> None:
    args = ctx["args"]
    if args.skip_enable:
        print("  (--skip-enable set: skipping)")
        return
    bundle_dir = ctx["bundle_dir"]
    manifest = ctx["manifest"]
    sm_file = bundle_dir / manifest["content"]["supermetrics"]["file"]
    sm_dict = _load_json_from_path(sm_file)
    # sm_dict is keyed by UUID: {uuid: {name, formula, description, unitId, resourceKinds}}
    sm_entries = list(sm_dict.values())
    names = [sm["name"] for sm in sm_entries]
    SM_RESOLVE_ATTEMPTS = 3
    SM_RESOLVE_DELAY = 5
    server_ids: Dict[str, str] = {}
    for attempt in range(1, SM_RESOLVE_ATTEMPTS + 1):
        server_ids = ctx["client"].list_supermetrics_by_name(names)
        missing = [n for n in names if n not in server_ids]
        if not missing:
            break
        if attempt < SM_RESOLVE_ATTEMPTS:
            print(f"    [resolve {attempt}/{SM_RESOLVE_ATTEMPTS}] "
                  f"{len(missing)} SM(s) not queryable yet, "
                  f"waiting {SM_RESOLVE_DELAY}s...")
            time.sleep(SM_RESOLVE_DELAY)

    # Build unverified map: {server_id: (name, resource_kinds)}
    unverified = {}
    for sm in sm_entries:
        name = sm["name"]
        sm_id = server_ids.get(name)
        if not sm_id:
            warn = f"Could not resolve ID for '{name}' -- skipping enable"
            _warn(warn)
            ctx["warnings"].append(warn)
            continue
        unverified[sm_id] = (name, sm["resourceKinds"])

    if not unverified:
        return

    SM_ENABLE_ATTEMPTS = 3
    SM_ENABLE_VERIFY_DELAY = 2
    policy_id = ctx["client"].get_default_policy_id()

    for attempt in range(1, SM_ENABLE_ATTEMPTS + 1):
        assign_errors = {}
        for sm_id, (name, rk) in list(unverified.items()):
            try:
                ctx["client"].enable_sm_on_default_policy(sm_id, name, rk)
            except RuntimeError as exc:
                assign_errors[sm_id] = str(exc)

        time.sleep(SM_ENABLE_VERIFY_DELAY)

        try:
            policy_xml = ctx["client"].export_default_policy_xml(policy_id)
            status = _verify_supermetrics_enabled(
                policy_xml, list(unverified.keys()))
        except RuntimeError as exc:
            _warn(f"Policy export failed on attempt {attempt}: {exc}")
            if attempt < SM_ENABLE_ATTEMPTS:
                continue
            for sm_id, (name, _) in unverified.items():
                warn = f"Enable FAILED for '{name}': could not verify"
                _warn(warn)
                ctx["warnings"].append(warn)
            break

        still_pending = {}
        for sm_id, (name, rk) in list(unverified.items()):
            if sm_id in assign_errors:
                warn = assign_errors[sm_id]
                _warn(warn)
                ctx["warnings"].append(warn)
            elif status.get(sm_id):
                _ok(f"Enabled: {name}")
            else:
                if attempt < SM_ENABLE_ATTEMPTS:
                    still_pending[sm_id] = (name, rk)
                else:
                    warn = (f"Enable FAILED for '{name}': assign returned 200 "
                            f"but SM not in Default Policy after "
                            f"{SM_ENABLE_ATTEMPTS} attempts")
                    _warn(warn)
                    ctx["warnings"].append(warn)

        unverified = still_pending
        if not unverified:
            break
        print(f"    [enable-verify {attempt}/{SM_ENABLE_ATTEMPTS}] "
              f"{len(unverified)} SM(s) not verified, retrying...")


def _install_builtin_metric_enables(ctx: Dict) -> None:
    """Enable built-in object-type metrics on the Default Policy.

    Reads manifest["content"]["builtin_metric_enables"]["items"], a list of
    dicts with adapter_kind, resource_kind, metric_key.  No-ops cleanly when
    the section is absent (most bundles won't have it).
    """
    args = ctx["args"]
    if args.skip_enable:
        print("  (--skip-enable set: skipping)")
        return

    manifest = ctx["manifest"]
    content = manifest.get("content") or {}
    bme_section = content.get("builtin_metric_enables")
    if not bme_section:
        return

    items = bme_section.get("items") or []
    if not items:
        return

    # Build entries list for the client method.
    entries = []
    for item in items:
        ak = item.get("adapter_kind", "")
        rk = item.get("resource_kind", "")
        mk = item.get("metric_key", "")
        if not (ak and rk and mk):
            _warn(f"Skipping malformed builtin_metric_enables entry: {item!r}")
            continue
        entries.append({"adapter_kind": ak, "resource_kind": rk, "metric_key": mk})

    if not entries:
        return

    try:
        result = ctx["client"].enable_builtin_metrics_on_default_policy(entries)
    except RuntimeError as exc:
        warn = f"Built-in metric enable failed: {exc}"
        _warn(warn)
        ctx["warnings"].append(warn)
        return

    for item in entries:
        mk = item["metric_key"]
        ak = item["adapter_kind"]
        rk = item["resource_kind"]
        was_already = result.get(mk, False)
        if was_already:
            _ok(f"Already enabled: {ak}/{rk} {mk}")
        else:
            _ok(f"Enabled: {ak}/{rk} {mk}")


def _install_customgroups(ctx: Dict) -> None:
    bundle_dir = ctx["bundle_dir"]
    manifest = ctx["manifest"]
    cg_file = bundle_dir / manifest["content"]["customgroups"]["file"]
    cg_data = _load_json_from_path(cg_file)
    if isinstance(cg_data, dict):
        cg_data = [cg_data]
    for cg_payload in cg_data:
        cg_name = cg_payload["resourceKey"]["name"]
        ctx["client"].upsert_custom_group(cg_payload)
        _ok(f"Upserted: {cg_name}")


def _install_symptoms(ctx: Dict) -> None:
    bundle_dir = ctx["bundle_dir"]
    manifest = ctx["manifest"]
    sym_file = bundle_dir / manifest["content"]["symptoms"]["file"]
    symptoms = _load_json_from_path(sym_file)
    for payload in symptoms:
        name = payload.get("name", "unknown")
        existing = None
        # Search by name
        page, page_size = 0, 1000
        while True:
            r = ctx["client"]._req("GET", "/api/symptomdefinitions",
                                   params={"page": page, "pageSize": page_size})
            if r.status_code != 200:
                _warn(f"Symptom list failed ({r.status_code})")
                break
            body = r.json()
            for sd in body.get("symptomDefinitions") or []:
                if sd.get("name") == name:
                    existing = sd
                    break
            if existing:
                break
            info = body.get("pageInfo") or {}
            total = info.get("totalCount", 0)
            if (page + 1) * page_size >= total:
                break
            page += 1

        if existing:
            payload["id"] = existing["id"]
            r = ctx["client"]._req("PUT", "/api/symptomdefinitions", json=payload)
            if r.status_code != 200:
                warn = f"Symptom update failed for '{name}' ({r.status_code}): {r.text}"
                _warn(warn)
                ctx["warnings"].append(warn)
                continue
            _ok(f"Updated: {name}")
        else:
            r = ctx["client"]._req("POST", "/api/symptomdefinitions", json=payload)
            if r.status_code not in (200, 201):
                warn = f"Symptom create failed for '{name}' ({r.status_code}): {r.text}"
                _warn(warn)
                ctx["warnings"].append(warn)
                continue
            _ok(f"Created: {name}")


def _install_alerts(ctx: Dict) -> None:
    bundle_dir = ctx["bundle_dir"]
    manifest = ctx["manifest"]
    alert_file = bundle_dir / manifest["content"]["alerts"]["file"]
    alerts = _load_json_from_path(alert_file)

    # Resolve symptom name → server ID map
    symptom_map: Dict[str, str] = {}
    page, page_size = 0, 1000
    while True:
        r = ctx["client"]._req("GET", "/api/symptomdefinitions",
                               params={"page": page, "pageSize": page_size})
        if r.status_code != 200:
            _warn(f"Symptom list for alert resolution failed ({r.status_code})")
            break
        body = r.json()
        for sd in body.get("symptomDefinitions") or []:
            if sd.get("name") and sd.get("id"):
                symptom_map[sd["name"]] = sd["id"]
        info = body.get("pageInfo") or {}
        total = info.get("totalCount", 0)
        if (page + 1) * page_size >= total:
            break
        page += 1

    for alert_data in alerts:
        name = alert_data.get("name", "unknown")

        # Build wire format with resolved symptom IDs
        try:
            wire = _alert_to_wire(alert_data, symptom_map)
        except Exception as exc:
            warn = f"Alert '{name}' wire conversion failed: {exc}"
            _warn(warn)
            ctx["warnings"].append(warn)
            continue

        # Upsert by name
        existing = None
        page = 0
        while True:
            r = ctx["client"]._req("GET", "/api/alertdefinitions",
                                   params={"page": page, "pageSize": 1000})
            if r.status_code != 200:
                break
            body = r.json()
            for ad in body.get("alertDefinitions") or []:
                if ad.get("name") == name:
                    existing = ad
                    break
            if existing:
                break
            info = body.get("pageInfo") or {}
            total = info.get("totalCount", 0)
            if (page + 1) * 1000 >= total:
                break
            page += 1

        if existing:
            wire["id"] = existing["id"]
            r = ctx["client"]._req("PUT", "/api/alertdefinitions", json=wire)
            if r.status_code != 200:
                warn = f"Alert update failed for '{name}' ({r.status_code}): {r.text}"
                _warn(warn)
                ctx["warnings"].append(warn)
                continue
            _ok(f"Updated: {name}")
        else:
            r = ctx["client"]._req("POST", "/api/alertdefinitions", json=wire)
            if r.status_code not in (200, 201):
                warn = f"Alert create failed for '{name}' ({r.status_code}): {r.text}"
                _warn(warn)
                ctx["warnings"].append(warn)
                continue
            _ok(f"Created: {name}")


# Alert subType enum.  Restated from vcfcf_core.alerts.loader.VALID_SUBTYPES
# because this script ships standalone in distribution zips and cannot import
# the factory (tests/test_install_alert_subtype.py pins the two in step).
# Wire format: knowledge/context/wire-formats/alertdef_symptomset_import.md
# section "Alert subType enum".
_ALERT_SUBTYPES = {
    18: "Availability",
    19: "Performance",
    20: "Capacity",
    21: "Compliance",
    22: "Configuration",
}
_ALERT_SUBTYPE_DEFAULT = 19


def _alert_sub_type(raw: Any) -> int:
    """``subType`` for an alert payload, with the core loader's rules.

    19 (Performance) only when absent or null; an integer string becomes the
    int; anything outside 18-22 (0, a bool, a float, other text) raises
    ValueError so the caller skips the alert with a warning, as ``validate``
    would have rejected it.
    """
    if raw is None:
        return _ALERT_SUBTYPE_DEFAULT
    value = raw
    if isinstance(raw, str) and raw.strip().lstrip("-").isdigit():
        try:
            value = int(raw.strip())
        except ValueError:  # isdigit() passes superscripts and "--19"; int() does not
            pass
    if isinstance(value, bool) or not isinstance(value, int) or value not in _ALERT_SUBTYPES:
        allowed = ", ".join(f"{k}={v}" for k, v in _ALERT_SUBTYPES.items())
        raise ValueError(f"sub_type must be one of {allowed}; got {raw!r}")
    return value


def _alert_to_wire(alert_data: dict, symptom_map: Dict[str, str]) -> dict:
    """Convert the stored alert payload to API wire format with resolved symptom IDs."""
    sub_type = _alert_sub_type(alert_data.get("sub_type"))
    ss = alert_data.get("symptom_sets") or {}
    top_op = (ss.get("operator") or "ALL").upper()
    sets = ss.get("sets") or []

    wire_sets = []
    for s in sets:
        defined_on = (s.get("defined_on") or "SELF").upper()
        op = (s.get("operator") or "ALL").upper()
        symptom_ids = []
        for sym in s.get("symptoms") or []:
            sym_name = sym.get("name", "")
            sid = symptom_map.get(sym_name)
            if not sid:
                raise RuntimeError(f"symptom '{sym_name}' not found on instance")
            symptom_ids.append(sid)
        wire_set: dict = {
            "type": "SYMPTOM_SET",
            "relation": defined_on,
            "symptomSetOperator": "AND" if op == "ALL" else "OR",
            "symptomDefinitionIds": symptom_ids,
        }
        tt = s.get("threshold_type")
        tv = s.get("threshold_value")
        if defined_on != "SELF" and tt:
            wire_set["aggregation"] = tt
            if tv is not None:
                wire_set["value"] = float(tv)
        wire_sets.append(wire_set)

    if len(wire_sets) == 1:
        base_ss = wire_sets[0]
    else:
        base_ss = {
            "type": "SYMPTOM_SET_COMPOSITE",
            "operator": "AND" if top_op == "ALL" else "OR",
            "symptom-sets": wire_sets,
        }

    state = {
        "severity": alert_data.get("criticality", "AUTO"),
        "base-symptom-set": base_ss,
        "impact": {
            "impactType": "BADGE",
            "detail": alert_data.get("impact_badge", "HEALTH"),
        },
    }

    return {
        "name": alert_data["name"],
        "description": alert_data.get("description", ""),
        "adapterKindKey": alert_data.get("adapter_kind", ""),
        "resourceKindKey": alert_data.get("resource_kind", ""),
        "waitCycles": alert_data.get("wait_cycles", 1),
        "cancelCycles": alert_data.get("cancel_cycles", 1),
        "type": alert_data.get("type", 16),
        "subType": sub_type,
        "states": [state],
    }


def _uninstall_symptoms(ctx: Dict) -> None:
    names: List[str] = ctx["names"]
    warnings = ctx["warnings"]
    # Build name→id map
    sym_ids: Dict[str, str] = {}
    page, page_size = 0, 1000
    while True:
        r = ctx["client"]._req("GET", "/api/symptomdefinitions",
                               params={"page": page, "pageSize": page_size})
        if r.status_code != 200:
            break
        body = r.json()
        for sd in body.get("symptomDefinitions") or []:
            if sd.get("name") in names and sd.get("id"):
                sym_ids[sd["name"]] = sd["id"]
        info = body.get("pageInfo") or {}
        total = info.get("totalCount", 0)
        if (page + 1) * page_size >= total:
            break
        page += 1
    for name in names:
        sid = sym_ids.get(name)
        if not sid:
            _warn(f"Symptom not found (already removed?): {name}")
            warnings.append(f"Symptom not found: {name}")
            continue
        r = ctx["client"]._req("DELETE", f"/api/symptomdefinitions/{sid}")
        if r.status_code in (200, 204):
            _ok(f"Deleted: {name}")
        else:
            warn = f"Symptom delete failed for '{name}' ({r.status_code})"
            _warn(warn)
            warnings.append(warn)


def _uninstall_alerts(ctx: Dict) -> None:
    names: List[str] = ctx["names"]
    warnings = ctx["warnings"]
    alert_ids: Dict[str, str] = {}
    page = 0
    while True:
        r = ctx["client"]._req("GET", "/api/alertdefinitions",
                               params={"page": page, "pageSize": 1000})
        if r.status_code != 200:
            break
        body = r.json()
        for ad in body.get("alertDefinitions") or []:
            if ad.get("name") in names and ad.get("id"):
                alert_ids[ad["name"]] = ad["id"]
        info = body.get("pageInfo") or {}
        total = info.get("totalCount", 0)
        if (page + 1) * 1000 >= total:
            break
        page += 1
    for name in names:
        aid = alert_ids.get(name)
        if not aid:
            _warn(f"Alert not found (already removed?): {name}")
            warnings.append(f"Alert not found: {name}")
            continue
        r = ctx["client"]._req("DELETE", f"/api/alertdefinitions/{aid}")
        if r.status_code in (200, 204):
            _ok(f"Deleted: {name}")
        else:
            warn = f"Alert delete failed for '{name}' ({r.status_code})"
            _warn(warn)
            warnings.append(warn)


def _build_reports_zip(reports_xml: str, marker: str, owner_id: str) -> bytes:
    """Build a reports content-zip from the reports XML string."""
    inner_buf = io.BytesIO()
    with zipfile.ZipFile(inner_buf, "w", zipfile.ZIP_DEFLATED) as inner:
        inner.writestr("content.xml", reports_xml)
    inner_bytes = inner_buf.getvalue()

    n_reports = reports_xml.count("<ReportDef ")

    outer_buf = io.BytesIO()
    with zipfile.ZipFile(outer_buf, "w", zipfile.ZIP_DEFLATED) as outer:
        outer.writestr(marker, owner_id)
        outer.writestr("reports.zip", inner_bytes)
        outer.writestr(
            "configuration.json",
            json.dumps({"reports": n_reports, "type": "CUSTOM"}, indent=2),
        )
    return outer_buf.getvalue()


def _install_reports(ctx: Dict) -> None:
    bundle_dir = ctx["bundle_dir"]
    manifest = ctx["manifest"]
    reports_file = bundle_dir / manifest["content"]["reports"]["file"]
    reports_xml = reports_file.read_text(encoding="utf-8")
    reports_zip = _build_reports_zip(reports_xml, ctx["marker"], ctx["owner_id"])
    result = ctx["client"].import_content_zip(reports_zip, "reports") or {}
    if _record_import_shortfalls(ctx, result):
        return
    n_reports = reports_xml.count("<ReportDef ")
    _ok(f"Imported {n_reports} report definition(s)")
    # Note: report uninstall (like view and dashboard uninstall) requires the
    # admin UI session via the SPA Ext.Direct path. Run --uninstall as admin.


def _uninstall_dashboards(ctx: Dict) -> None:
    ui_client = ctx["ui_client"]
    names: List[str] = ctx["names"]
    warnings = ctx["warnings"]
    all_dashboards = ui_client.list_dashboards()
    dash_by_name: Dict[str, str] = {
        d["name"]: d["id"] for d in all_dashboards if d.get("name") and d.get("id")
    }
    to_delete: List[Tuple[str, str]] = []
    for name in names:
        if name in dash_by_name:
            to_delete.append((dash_by_name[name], name))
        else:
            _warn(f"Dashboard not found (already removed?): {name}")
            warnings.append(f"Dashboard not found: {name}")
    if to_delete:
        try:
            ui_client.delete_dashboards(to_delete)
            for _, name in to_delete:
                _ok(f"Deleted: {name}")
        except Exception as exc:
            warn = f"Dashboard batch delete failed: {exc}"
            _warn(warn)
            warnings.append(warn)


def _uninstall_views(ctx: Dict) -> None:
    ui_client = ctx["ui_client"]
    names: List[str] = ctx["names"]
    warnings = ctx["warnings"]
    all_views = ui_client.list_views()
    view_by_name: Dict[str, str] = {
        v.get("name", ""): v.get("viewDefinitionKey", v.get("id", ""))
        for v in all_views
        if v.get("name") and (v.get("viewDefinitionKey") or v.get("id"))
    }
    for name in names:
        view_id = view_by_name.get(name)
        if not view_id:
            _warn(f"View not found (already removed?): {name}")
            warnings.append(f"View not found: {name}")
            continue
        try:
            ui_client.delete_view(view_id, name)
            _ok(f"Deleted: {name}")
        except RuntimeError as exc:
            warn = f"View delete failed for '{name}': {exc}"
            _warn(warn)
            warnings.append(warn)


def _uninstall_reports(ctx: Dict) -> None:
    """Delete report definitions via the UI session (SPA Ext.Direct path).

    Report delete requires admin UI session (same constraint as dashboards
    and views -- the needs_ui guard in the registry enforces this).
    """
    ui_client = ctx["ui_client"]
    names: List[str] = ctx["names"]
    warnings = ctx["warnings"]
    all_reports = ui_client.list_reports()
    report_by_name: Dict[str, str] = {
        r.get("name", ""): r.get("id", "")
        for r in all_reports
        if r.get("name") and r.get("id")
    }
    to_delete: List[Tuple[str, str]] = []
    for name in names:
        report_id = report_by_name.get(name)
        if not report_id:
            _warn(f"Report not found (already removed?): {name}")
            warnings.append(f"Report not found: {name}")
            continue
        to_delete.append((report_id, name))
    if to_delete:
        try:
            ui_client.delete_reports(to_delete)
            for _, name in to_delete:
                _ok(f"Deleted: {name}")
        except RuntimeError as exc:
            warn = f"Report batch delete failed: {exc}"
            _warn(warn)
            warnings.append(warn)


def _uninstall_supermetrics(ctx: Dict) -> None:
    names: List[str] = ctx["names"]
    warnings = ctx["warnings"]
    force: bool = ctx["force"]
    sm_ids = ctx["client"].find_supermetric_ids(names)
    for name in names:
        sm_id = sm_ids.get(name)
        if not sm_id:
            _warn(f"Super metric not found (already removed?): {name}")
            warnings.append(f"Super metric not found: {name}")
            continue
        sc = ctx["client"].delete_supermetric(sm_id)
        if sc in (200, 204):
            _ok(f"Deleted: {name}")
        elif sc == 409:
            warn = f"Skipped: {name} (referenced by other content; use --force to override)"
            _warn(warn)
            warnings.append(warn)
        else:
            warn = f"Super metric delete returned HTTP {sc} for '{name}'"
            _warn(warn)
            warnings.append(warn)


def _uninstall_builtin_metric_enables_note(ctx: Dict) -> None:
    """Print a note listing built-in metrics this bundle enabled.

    Built-in metric enables are intentionally NOT reversed on uninstall:
    the Default Policy is shared state and other bundles or the operator
    may depend on the same metric being active.  This function prints a
    human-readable reminder so operators can make an informed decision.
    """
    manifest = ctx["manifest"]
    content = manifest.get("content") or {}
    bme_section = content.get("builtin_metric_enables")
    if not bme_section:
        return
    items = bme_section.get("items") or []
    if not items:
        return
    print("  NOTE: the following built-in metrics were enabled by this bundle and")
    print("  remain enabled in the Default Policy (policy is shared state):")
    for item in items:
        ak = item.get("adapter_kind", "?")
        rk = item.get("resource_kind", "?")
        mk = item.get("metric_key", "?")
        reason = item.get("reason", "")
        suffix = f"  # {reason}" if reason else ""
        print(f"    {ak}/{rk} {mk}{suffix}")
    print("  To disable, edit the Default Policy in the VCF Ops UI.")


def _uninstall_customgroups(ctx: Dict) -> None:
    names: List[str] = ctx["names"]
    warnings = ctx["warnings"]
    cg_ids = ctx["client"].find_customgroup_ids(names)
    for name in names:
        cg_id = cg_ids.get(name)
        if not cg_id:
            _warn(f"Custom group not found (already removed?): {name}")
            warnings.append(f"Custom group not found: {name}")
            continue
        sc = ctx["client"].delete_customgroup(cg_id)
        if sc in (200, 204):
            _ok(f"Deleted: {name}")
        else:
            warn = f"Custom group delete returned HTTP {sc} for '{name}'"
            _warn(warn)
            warnings.append(warn)


# ---------------------------------------------------------------------------
# Registry helpers: detection predicates using the new manifest_key pattern
# ---------------------------------------------------------------------------

def _bundle_has_key(bundle: Dict, manifest_key: str) -> bool:
    """True if the bundle manifest has the given content key AND its file exists."""
    manifest = bundle["manifest"]
    content = manifest.get("content") or {}
    section = content.get(manifest_key)
    if not section:
        return False
    rel = section.get("file", "")
    if not rel:
        return False
    return (bundle["dir"] / rel).exists()


def _bundle_uninstall_names(bundle: Dict, content_type: str) -> List[str]:
    """Return the list of names to uninstall for a given content type."""
    content = bundle["manifest"].get("content") or {}
    section = content.get(content_type) or {}
    return [item["name"] for item in (section.get("items") or []) if item.get("name")]


# Registry: sorted by install_order at run time (list position is not the order).
# Install order: supermetrics 1, customgroups 1.5, views+dashboards 2, sm_enable 3,
# builtin_metric_enables 3.5, reports 5, symptoms 6, alerts 7. install.ps1 must
# match (tests/test_installer_install_order.py).
# To add a new content type, append an entry here.  No other changes needed.
_CONTENT_REGISTRY: List[Dict] = [
    {
        "content_type": "supermetrics",
        "manifest_key": "supermetrics",
        "install_label": "Importing super metrics...",
        "install_fn": _install_supermetrics,
        "install_order": 1,
        "uninstall_label": "Deleting super metric(s)...",
        "uninstall_fn": _uninstall_supermetrics,
        "uninstall_order": 40,
        "needs_ui": False,
    },
    {
        "content_type": "views_and_dashboards",  # synthetic: triggered by dashboards key
        "manifest_key": "dashboards",
        "install_label": "Importing view + dashboard...",
        "install_fn": _install_dashboards,
        "install_order": 2,
        "uninstall_label": None,
        "uninstall_fn": None,
        "uninstall_order": None,
        "needs_ui": False,
    },
    {
        "content_type": "sm_enable",  # synthetic: triggered by supermetrics key
        "manifest_key": "supermetrics",
        "install_label": "Enabling super metrics on Default Policy...",
        "install_fn": _install_sm_enable,
        "install_order": 3,
        "uninstall_label": None,
        "uninstall_fn": None,
        "uninstall_order": None,
        "needs_ui": False,
    },
    {
        "content_type": "builtin_metric_enables",
        "manifest_key": "builtin_metric_enables",
        "install_label": "Enabling built-in metric(s) on Default Policy...",
        "install_fn": _install_builtin_metric_enables,
        "install_order": 3.5,  # after sm_enable (3), before reports (5)
        # Uninstall prints a console note but does NOT disable built-in metrics:
        # Default Policy is shared state; other bundles or the operator may rely
        # on the same metric.  A future --revert-metric-enables flag can add the
        # disable path if explicitly requested.
        "uninstall_label": "Noting built-in metric(s) enabled by this bundle...",
        "uninstall_fn": _uninstall_builtin_metric_enables_note,
        "uninstall_order": 45,  # after custom group uninstall (38) and SM uninstall (40)
        "needs_ui": False,
    },
    {
        "content_type": "customgroups",
        "manifest_key": "customgroups",
        "install_label": "Upserting custom group(s)...",
        "install_fn": _install_customgroups,
        # 1.5: after super metrics (1), which a group rule may reference, and
        # BEFORE dashboards (2). A View widget pinned to a helper custom group
        # binds the pin by display name at dashboard import, so the group must
        # already exist or the dashboard stays deferred (#302). Matches the
        # factory syncer, which creates groups first.
        "install_order": 1.5,
        "uninstall_label": "Deleting custom group(s)...",
        "uninstall_fn": _uninstall_customgroups,
        # 38: before super metrics (40), the reverse of install, as the
        # factory syncer uninstalls (reverse sync_order).
        "uninstall_order": 38,
        "needs_ui": False,
    },
    {
        "content_type": "reports",
        "manifest_key": "reports",
        "install_label": "Importing report definition(s)...",
        "install_fn": _install_reports,
        "install_order": 5,
        "uninstall_label": None,
        "uninstall_fn": None,
        "uninstall_order": None,
        "needs_ui": False,
        # Uninstall is handled by a separate uninstall-only registry entry below.
    },
    {
        "content_type": "symptoms",
        "manifest_key": "symptoms",
        "install_label": "Upserting symptom definition(s)...",
        "install_fn": _install_symptoms,
        "install_order": 6,
        "uninstall_label": "Deleting symptom definition(s)...",
        "uninstall_fn": _uninstall_symptoms,
        "uninstall_order": 55,
        "needs_ui": False,
    },
    {
        "content_type": "alerts",
        "manifest_key": "alerts",
        "install_label": "Upserting alert definition(s)...",
        "install_fn": _install_alerts,
        "install_order": 7,
        "uninstall_label": "Deleting alert definition(s)...",
        "uninstall_fn": _uninstall_alerts,
        "uninstall_order": 35,
        "needs_ui": False,
    },
    # Uninstall-only entries for dashboards, reports, and views (reverse of install):
    # Order: dashboards first (10), then reports (15, since reports reference views),
    # then views (20). All require the admin UI session via SPA Ext.Direct.
    {
        "content_type": "dashboards",
        "manifest_key": None,    # uninstall-only; no install predicate
        "install_label": None,
        "install_fn": None,
        "install_order": None,
        "uninstall_label": "Deleting dashboard(s)...",
        "uninstall_fn": _uninstall_dashboards,
        "uninstall_order": 10,
        "needs_ui": True,
    },
    {
        "content_type": "reports",
        "manifest_key": None,    # uninstall-only; install is handled above
        "install_label": None,
        "install_fn": None,
        "install_order": None,
        "uninstall_label": "Deleting report definition(s)...",
        "uninstall_fn": _uninstall_reports,
        "uninstall_order": 15,
        "needs_ui": True,
    },
    {
        "content_type": "views",
        "manifest_key": None,
        "install_label": None,
        "install_fn": None,
        "install_order": None,
        "uninstall_label": "Deleting view(s)...",
        "uninstall_fn": _uninstall_views,
        "uninstall_order": 20,
        "needs_ui": True,
    },
]


# ---------------------------------------------------------------------------
# Per-bundle install / uninstall
# ---------------------------------------------------------------------------

def _install_one_bundle(bundle: Dict, global_ctx: Dict, step_base: int,
                        total_steps: int) -> Tuple[int, List[str], List[str]]:
    """Install one bundle.  Returns (steps_used, warnings, advisories).

    ``warnings`` fail the install (exit 2).  ``advisories`` do not: they
    are things the operator must SEE but that did not break anything,
    e.g. an import that finished without changing existing content.
    They are printed as a trailer in BOTH summary branches so the last
    line an operator reads is never an unqualified "all successful"
    while a WARN above it says content was not updated.
    """
    manifest = bundle["manifest"]
    bundle_dir = bundle["dir"]
    name = _bundle_display_name(bundle)

    active = [
        e for e in _CONTENT_REGISTRY
        if e["install_fn"] is not None
        and e["manifest_key"] is not None
        and _bundle_has_key(bundle, e["manifest_key"])
    ]
    active.sort(key=lambda e: e["install_order"])

    warnings: List[str] = []
    advisories: List[str] = []
    ctx: Dict = {
        **global_ctx,
        "bundle_dir": bundle_dir,
        "manifest": manifest,
        "warnings": warnings,
        "advisories": advisories,
        "names": [],
    }

    step = step_base
    for entry in active:
        step += 1
        _step(step, total_steps, f"[{name}] {entry['install_label']}")
        entry["install_fn"](ctx)

    return step - step_base, warnings, [f"[{name}] {a}" for a in advisories]


def _uninstall_one_bundle(bundle: Dict, global_ctx: Dict, step_base: int,
                          total_steps: int) -> Tuple[int, List[str]]:
    """Uninstall one bundle.  Returns (steps_used, warnings)."""
    manifest = bundle["manifest"]
    name = _bundle_display_name(bundle)

    active = [
        e for e in _CONTENT_REGISTRY
        if e["uninstall_fn"] is not None
        and e["uninstall_order"] is not None
        and _bundle_uninstall_names(bundle, e["content_type"])
    ]
    active.sort(key=lambda e: e["uninstall_order"])

    warnings: List[str] = []
    ctx: Dict = {
        **global_ctx,
        "bundle_dir": bundle["dir"],
        "manifest": manifest,
        "warnings": warnings,
        "names": [],
    }

    step = step_base
    for entry in active:
        names = _bundle_uninstall_names(bundle, entry["content_type"])
        if not names:
            continue
        step += 1
        label = entry["uninstall_label"].replace("...", f" ({len(names)})...")
        _step(step, total_steps, f"[{name}] {label}")
        ctx["names"] = names
        entry["uninstall_fn"](ctx)

    return step - step_base, warnings


# ---------------------------------------------------------------------------
# Install flow
# ---------------------------------------------------------------------------
def _run_install(args: argparse.Namespace, host: str, user: str,
                 auth_source: str, password: str, verify_ssl: bool,
                 selected_bundles: List[Dict]) -> None:

    # Count active entries per bundle for total step count
    total_content_steps = 0
    for bundle in selected_bundles:
        total_content_steps += sum(
            1 for e in _CONTENT_REGISTRY
            if e["install_fn"] is not None
            and e["manifest_key"] is not None
            and _bundle_has_key(bundle, e["manifest_key"])
        )

    TOTAL_STEPS = 3 + total_content_steps   # auth + marker + owner + content
    print(f"\nInstalling {len(selected_bundles)} bundle(s) onto {host}...")

    client = Client(host, user, password, auth_source, verify_ssl)
    step = 0

    step += 1
    _step(step, TOTAL_STEPS, f"Authenticating as {user}@{host} (auth: {auth_source}) ...")
    client.authenticate()
    _ok("Authenticated")

    step += 1
    _step(step, TOTAL_STEPS, "Discovering instance marker filename...")
    marker = client.discover_marker_filename()
    _ok(f"Marker: {marker}")

    step += 1
    _step(step, TOTAL_STEPS, "Resolving current user ID...")
    owner_id = client.get_current_user()["id"]
    _ok(f"Owner user ID: {owner_id}")

    # Before anything is imported: a widget type this instance's version
    # cannot import loses every dashboard in the import (issue #199).
    _preflight_widget_floors(client, selected_bundles)

    global_ctx: Dict = {
        "client": client,
        "ui_client": None,
        "marker": marker,
        "owner_id": owner_id,
        "username": client._user,
        "args": args,
        "force": False,
        # Shared by every bundle's ctx (a shallow copy keeps this list).
        "imported_dashboards": [],
    }

    all_warnings: List[str] = []
    all_advisories: List[str] = []
    for bundle in selected_bundles:
        used, warnings, advisories = _install_one_bundle(
            bundle, global_ctx, step, TOTAL_STEPS
        )
        step += used
        all_warnings.extend(warnings)
        all_advisories.extend(advisories)

    mat_warnings, mat_notes = _report_materialization(
        client, global_ctx["imported_dashboards"], args
    )
    all_warnings.extend(mat_warnings)

    def _print_advisories() -> None:
        """Trailer printed in BOTH summary branches.

        Without it, a run whose dashboard import changed nothing ends on
        "Done. All content installed successfully.", which is the
        reports-green-while-broken defect this check exists to kill,
        relocated to the summary. The last line is what an operator
        remembers. Advisories never touch the exit code.
        """
        if mat_notes:
            print()
            print(f"{len(mat_notes)} dashboard(s) need a later look "
                  f"(installed, but not confirmed finished building):")
            for a in mat_notes:
                print(f"  ATTENTION  {a}")
        if not all_advisories:
            return
        print()
        print(f"{len(all_advisories)} item(s) need attention "
              f"(nothing failed, but content on the instance did not change):")
        for a in all_advisories:
            print(f"  ATTENTION  {a}")

    print()
    # Materialization lines are classified by their prefix, never by the
    # substring test below: a dashboard or resource name containing
    # "enable" or "resolve" must not read as a super metric enable failure.
    enable_warnings = [
        w for w in all_warnings
        if not w.startswith("MATERIALIZATION ")
        and ("enable" in w.lower() or "resolve" in w.lower())
    ]
    other_warnings = [w for w in all_warnings if w not in enable_warnings]
    if enable_warnings or other_warnings:
        total = len(enable_warnings) + len(other_warnings)
        # An error-severity import shortfall (W4): the content is not on the
        # instance and will not appear, so the run must not end on the
        # "expected, refresh after ~5 minutes" note; it ends on what was lost.
        lost = [w for w in other_warnings if w.startswith(_SHORTFALL_PREFIX)]
        print(f"Done with {total} warning(s):")
        for w in enable_warnings + other_warnings:
            print(f"  {'ERROR' if w in lost else 'WARN'}  {w}")
        if enable_warnings:
            print("Content was imported but one or more super metrics could not be enabled.")
        print()
        if not lost:
            print("NOTE: VCF Operations needs roughly 5 minutes to finish ingesting and")
            print("configuring imported content. Until that completes:")
            print("  - Dashboards may render with empty widgets")
            print("  - View columns may show 'No data'")
            print("  - Newly enabled super metrics will report no values")
            print("This is expected. Refresh after ~5 minutes.")
        _print_advisories()
        for line in _lost_import_lines(lost):
            print(line)
        sys.exit(2)
    else:
        if all_advisories or mat_notes:
            # N-18: not "below". The 5-minute NOTE block prints between
            # this line and the advisories, so the list is seven lines
            # away, not immediately under. The ordering is deliberate
            # (NOTE is boilerplate, the advisory is the delta and must be
            # the last thing the operator reads), so the wording moves.
            print("Done. No failures, but see the attention list at the "
                  "end of this output.")
        else:
            print("Done. All content installed successfully.")
        print()
        print("NOTE: VCF Operations needs roughly 5 minutes to finish ingesting and")
        print("configuring imported content. Until that completes:")
        print("  - Dashboards may render with empty widgets")
        print("  - View columns may show 'No data'")
        print("  - Newly enabled super metrics will report no values")
        print("This is expected. Refresh after ~5 minutes.")
        _print_advisories()


# ---------------------------------------------------------------------------
# Uninstall flow
# ---------------------------------------------------------------------------
def _run_uninstall(args: argparse.Namespace, host: str, user: str,
                   auth_source: str, password: str, verify_ssl: bool,
                   selected_bundles: List[Dict]) -> None:
    force = args.force

    # Determine if any bundle needs UI session (dashboards/views/reports).
    needs_ui = any(
        e["needs_ui"] and e["uninstall_fn"] is not None
        and _bundle_uninstall_names(bundle, e["content_type"])
        for bundle in selected_bundles
        for e in _CONTENT_REGISTRY
    )

    # Admin guard is enforced in main() before credentials are prompted.
    # _run_uninstall trusts that user=="admin" when needs_ui is True.

    # Count total uninstall steps
    total_content_steps = 0
    for bundle in selected_bundles:
        for e in _CONTENT_REGISTRY:
            if e["uninstall_fn"] is not None and e["uninstall_order"] is not None:
                if _bundle_uninstall_names(bundle, e["content_type"]):
                    total_content_steps += 1

    n_steps = 1 + total_content_steps
    if needs_ui:
        n_steps += 2  # ui_auth + ui_logout

    print(f"\nUninstalling {len(selected_bundles)} bundle(s) from {host}...")
    if force:
        print("(--force: skipping dependency checks)")
    print("Content to remove:")
    for bundle in selected_bundles:
        bname = _bundle_display_name(bundle)
        print(f"  Bundle: {bname}")
        for e in _CONTENT_REGISTRY:
            if e["uninstall_fn"] is not None and e["uninstall_order"] is not None:
                names = _bundle_uninstall_names(bundle, e["content_type"])
                if names:
                    print(f"    {e['content_type'].capitalize()} ({len(names)}): {', '.join(names)}")

    # Check that any bundle has something to remove
    has_anything = any(
        _bundle_uninstall_names(bundle, e["content_type"])
        for bundle in selected_bundles
        for e in _CONTENT_REGISTRY
        if e["uninstall_fn"] is not None
    )
    if not has_anything:
        print("  (nothing to remove -- bundles contain no removable content)")
        sys.exit(0)

    warnings_all: List[str] = []
    step = 0

    suite_client = Client(host, user, password, auth_source, verify_ssl)
    ui_client = UIClient(host, user, password, auth_source, verify_ssl)

    step += 1
    _step(step, n_steps, f"Authenticating as {user}@{host} (auth: {auth_source}) ...")
    suite_client.authenticate()
    _ok("Authenticated")

    if needs_ui:
        step += 1
        _step(step, n_steps, "Starting UI session (for dashboard/view/report delete)...")
        ui_client.login()
        _ok("UI session established")

    global_ctx: Dict = {
        "client": suite_client,
        "ui_client": ui_client if needs_ui else None,
        "marker": None,
        "owner_id": None,
        "args": args,
        "force": force,
    }

    for bundle in selected_bundles:
        used, warnings = _uninstall_one_bundle(bundle, global_ctx, step, n_steps)
        step += used
        warnings_all.extend(warnings)

    if needs_ui:
        step += 1
        _step(step, n_steps, "Closing UI session...")
        ui_client.logout()
        _ok("UI session closed")

    print()
    if warnings_all:
        not_found = [w for w in warnings_all if "not found" in w]
        real_failures = [w for w in warnings_all if "not found" not in w]
        if real_failures:
            print(f"Done with errors ({len(real_failures)} delete failure(s)):")
            for w in real_failures:
                print(f"  WARN  {w}")
            if not_found:
                print(f"  ({len(not_found)} item(s) were already absent)")
            sys.exit(2)
        else:
            print(f"Done. All targeted content was already absent ({len(not_found)} item(s) not found).")
    else:
        print("Done. All content removed successfully.")


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
def main() -> None:
    ap = argparse.ArgumentParser(
        description="Install or uninstall VCF Content Factory bundles.\n"
                    "Run with no arguments for interactive install prompts.\n"
                    "Use --uninstall to remove all content these bundles installed.\n"
                    "Note: Uninstall requires the 'admin' account for dashboard/view cleanup.")
    ap.add_argument("--install", action="store_true",
                    help="Install mode (default when no mode flag is given)")
    ap.add_argument("--uninstall", action="store_true",
                    help="Uninstall mode: delete all content in selected bundles from the instance")
    ap.add_argument("--force", action="store_true",
                    help="With --uninstall: skip dependency checks and delete unconditionally")
    ap.add_argument("--host",
                    default=os.environ.get("VCFOPS_HOST"),
                    help="VCF Ops hostname or IP (env: VCFOPS_HOST)")
    ap.add_argument("--user",
                    default=os.environ.get("VCFOPS_USER"),
                    help="VCF Ops username (env: VCFOPS_USER)")
    ap.add_argument("--password",
                    default=os.environ.get("VCFOPS_PASSWORD"),
                    help="VCF Ops password (env: VCFOPS_PASSWORD)")
    ap.add_argument("--auth-source",
                    default=os.environ.get("VCFOPS_AUTH_SOURCE", ""),
                    help="Auth source: 'local' or a domain name like corp.example.com "
                         "(env: VCFOPS_AUTH_SOURCE, default: Local)")
    ap.add_argument("--skip-ssl-verify", action="store_true",
                    default=(os.environ.get("VCFOPS_VERIFY_SSL", "true").lower() == "false"),
                    help="Disable TLS certificate verification (lab use only)")
    ap.add_argument("--skip-enable", action="store_true",
                    help="(install mode) Skip enabling super metrics on Default Policy")
    ap.add_argument("--skip-materialization-check", action="store_true",
                    help="(install mode) Skip the post-import check that each dashboard "
                         "finished building (one dashboard export plus an adapter-kind "
                         "read). Default: check, and exit 2 when a dashboard waits on "
                         "an adapter that is not installed.")
    ap.add_argument("--materialization-wait", type=int, default=None, metavar="SECONDS",
                    help="(install mode) Seconds to wait before the one re-check of "
                         "dashboards still building (default 180, or "
                         "VCFCF_MATERIALIZATION_WAIT_S; capped at 900; 0 reports at once)")
    args = ap.parse_args()

    if args.uninstall and args.install:
        _die("--install and --uninstall are mutually exclusive.")
    if args.force and not args.uninstall:
        _die("--force is only valid with --uninstall.")

    # Discover bundles before prompting for credentials.
    bundles = _discover_bundles()
    if not bundles:
        _die("No bundles found. Expected bundles/<slug>/bundle.json or a legacy content/ directory.")

    mode = "uninstall" if args.uninstall else "install"
    selected = _select_bundles(bundles, mode)
    _print_selection_summary(selected, mode)

    # Early admin-guard: if any selected bundle requires the UI session
    # (dashboards/views/reports), check the user before prompting for
    # credentials or printing any further output.  When the user is already
    # known from --user / VCFOPS_USER, this fires immediately after bundle
    # selection so the operator sees the error before any credential prompts.
    # When the user is not yet known (interactive), the check is deferred to
    # after _prompt_credentials below.
    if args.uninstall:
        _ui_needed = any(
            e["needs_ui"] and e["uninstall_fn"] is not None
            and _bundle_uninstall_names(bundle, e["content_type"])
            for bundle in selected
            for e in _CONTENT_REGISTRY
        )
        if _ui_needed and args.user and args.user != "admin":
            print(
                "ERROR: Dashboard, view, and report uninstall requires the 'admin' account.\n"
                "       VCF Ops locks imported content to admin ownership. Only the\n"
                "       admin user's UI session can delete them.\n"
                "       Re-run with --user admin (or set VCFOPS_USER=admin).",
                file=sys.stderr,
            )
            sys.exit(1)
    else:
        _ui_needed = False

    cred_mode = "uninstaller" if args.uninstall else "installer"
    host, user, auth_source, password, skip_ssl = _prompt_credentials(args, cred_mode)

    # Post-credentials admin guard: covers the interactive case where user
    # was not set via --user / VCFOPS_USER and was entered at the prompt.
    if args.uninstall and _ui_needed and user != "admin":
        print(
            "ERROR: Dashboard, view, and report uninstall requires the 'admin' account.\n"
            "       VCF Ops locks imported content to admin ownership. Only the\n"
            "       admin user's UI session can delete them.\n"
            "       Re-run with --user admin (or set VCFOPS_USER=admin).",
            file=sys.stderr,
        )
        sys.exit(1)

    if skip_ssl:
        print("WARNING: TLS certificate verification disabled.")
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    verify_ssl = not skip_ssl

    if args.uninstall:
        _run_uninstall(args, host, user, auth_source, password, verify_ssl, selected)
    else:
        _run_install(args, host, user, auth_source, password, verify_ssl, selected)


if __name__ == "__main__":
    main()
