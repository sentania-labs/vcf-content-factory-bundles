# Capacity Assessment

Single-dashboard capacity review for a VCF Ops admin. Top section answers 'how many more VMs can I deploy?' with post-HA CPU/memory free percentages, VMs-that-fit projections, and days-until-runout pulled from VCF Ops capacity analytics. Bottom section surfaces right-sizing opportunities — VMs flagged by VCF Ops as oversized, undersized, or idle, with 95th-percentile demand justification columns and current-to-target resize recommendations. Color thresholds throughout use the standard green/yellow/orange/red stoplight. Install this bundle on any VCF Ops 9+ instance to get an opinionated capacity dashboard ready for quarterly reviews.

## Intent

- **Audience**: VCF Ops admin doing a quarterly capacity review or
  a pre-deployment sanity check on a vSphere environment. Not a
  real-time operations dashboard — a *planning* dashboard.
- **Core question**: "Can I take on more workload, and if not, where
  can I find capacity?" Two sub-questions shape the two sections.
  - **Capacity section**: how much headroom exists, post-HA, and
    where is it? Which clusters are already tight?
  - **Right-Sizing section**: where has VCF Ops's capacity engine
    already identified reclamation opportunity inside existing
    workloads? Oversized, undersized, idle VMs.
- **Scope**: entire environment. Self-provider widgets pinned to
  `vSphere World`. No cluster/datacenter picker — this is an
  environment-wide snapshot, not a drill-down tool.
- **Framing bias**: post-HA adjusted figures everywhere capacity
  is measured. Raw cluster capacity overstates real admission
  capacity; post-HA matches what vSphere will actually schedule.
- **Color system**: green/yellow/orange/red stoplight, with
  specific band boundaries (15/30/50) for post-HA free%. Set
  once in the dashboard intro text so all widgets share a
  consistent vocabulary.

## Layout

```
+======================================================================+
|  [VCF Content Factory] Capacity Assessment & Right-Sizing            |
+======================================================================+
|                                                                      |
|  === SECTION 1: Capacity Assessment ================================ |
|  ( TextDisplay intro — post-HA framing, stoplight legend )           |
|                                                                      |
|  +-----------+-----------+-----------+-----------+                   |
|  | Powered-  | Avg CPU   | Avg Mem   | Running   |  <- Scoreboard    |
|  | On VMs    | Free %    | Free %    | Hosts     |     (env-level    |
|  |           | post-HA   | post-HA   |           |      KPIs)        |
|  +-----------+-----------+-----------+-----------+                   |
|                                                                      |
|  +----------------------------------------------------------------+  |
|  |                                                                |  |
|  |   Cluster Heatmap — CPU Free % post-HA                         |  |
|  |   colored 15/30/50 stoplight, sized by Running VMs,            |  |
|  |   grouped by Datacenter                                        |  |
|  |                                                                |  |
|  +----------------------------------------------------------------+  |
|                                                                      |
|  +----------------------------------------------------------------+  |
|  |   View: [VCF Content Factory] Cluster Capacity Overview        |  |
|  |   ( cluster table with post-HA CPU/mem, days-until-runout,     |  |
|  |     VMs-that-fit, colored columns )                            |  |
|  +----------------------------------------------------------------+  |
|                                                                      |
|  === SECTION 2: Right-Sizing Opportunities ========================= |
|  ( TextDisplay intro — oversized/undersized/idle definitions,        |
|    95th-percentile demand column hint, color legend )                |
|                                                                      |
|  +--------+--------+--------+-------------+----------------+         |
|  |Over-   |Under-  |Idle    |Reclaimable  |Reclaimable     |   <-    |
|  |sized   |sized   |VMs     |vCPUs (sum)  |Memory GB (sum) | 5-box   |
|  |VMs     |VMs     |        |  ** NEW **  |  ** NEW **     | layout  |
|  +--------+--------+--------+-------------+----------------+         |
|                                                                      |
|  +----------------------------+  +-----------------------------+     |
|  |  Top 15 VMs by             |  |  Top 15 VMs by              |     |
|  |  Reclaimable vCPUs         |  |  Reclaimable Memory (GB)    |     |
|  |  ( ParetoAnalysis )        |  |  ( ParetoAnalysis )         |     |
|  +----------------------------+  +-----------------------------+     |
|                                                                      |
|  +----------------------------------------------------------------+  |
|  |   View: [VCF Content Factory] VM Right-Sizing Candidates       |  |
|  |   ( VM table with oversized/undersized/idle flags, target      |  |
|  |     vCPU + memory recommendations, 95th-percentile justif. )   |  |
|  +----------------------------------------------------------------+  |
+======================================================================+
```

Boxes marked `** NEW **` are the redesign delta. Everything else
reflects the existing build and is preserved.

## Design Decisions

| Decision | Choice | Rationale |
|---|---|---|
| Section split | Capacity (top) + Right-Sizing (bottom) | Two different decisions driving two different investigations. Co-locating them in one dashboard reflects that they're the two dimensions of the same quarterly review. |
| Scope mechanism | Self-provider widgets pinned to vSphere World | Environment-wide snapshot. No picker — reduces friction for the "just show me everything" use case. |
| Post-HA framing | All capacity metrics use post-HA-adjusted SMs | Raw capacity is misleading. Post-HA is what matters for planning decisions. |
| Cluster-level counts | Per-cluster rollup SMs (Oversized/Undersized/Idle counts) | Cluster is the planning unit; VM-level flag data rolled up via `depth=2` walks makes clusters the row identity in the scoreboard. |
| Capacity reclaim display | **Environment-level sum** of reclaimable vCPUs and memory (new, redesigned) | Right-Sizing Scoreboard's *point* is "how much capacity could we get back." Per-cluster counts answer "how many VMs to look at"; sum of reclaim answers "how big is the prize." Both are useful; the fourth box should be a prize figure, not a repeat of "VM count." |
| Memory units in scoreboard | GB (computed in SM via `/1048576`) | `summary|oversized|memory` is KB. Displaying KB at environment level produces nine-digit numbers. Convert in the SM so the Scoreboard renders human-scale values. |
| Scoreboard layout | 5 boxes in a single row (`box_columns: 5`) | Fits the existing `w=12, h=3` real estate. Single row preserves parallel reading. Alternative considered: split into two Scoreboards ("Flagged VMs" counts + "Reclaimable Capacity") — rejected because it doubles widget count for the same info density. |
| ParetoAnalysis widgets | Keep unchanged | Top-15-by-reclaim-vCPUs and Top-15-by-reclaim-memory both already target VirtualMachine directly, which is correct. These were not broken. |
| View widgets | Keep unchanged | Cluster Capacity Overview and VM Right-Sizing Candidates views both still work; no design debt here. |

## Out of Scope

- Adding a cluster/datacenter picker. Current environment-wide
  scope is by design. If per-cluster drill-down is wanted, that's
  a separate dashboard (future v2, not this redesign).
- Adding symptoms/alerts around capacity thresholds. The dashboard
  is for planning reviews, not operational alerting.
- Modifying existing super metrics (e.g., the VM target vCPU / memory
  SMs). They work, and their semantics are load-bearing for the
  view tables — don't touch.
- Re-examining the Capacity section. It's not broken.

## Origin

This is a **retroactive design artifact**. The capacity-assessment
bundle was authored in a single commit (`e9217af`, 2026-04-11) as a
16-file drop without a design trail — 9 days before the
plan-mode-plus-design-artifact discipline was codified (memory note
`feedback_plan_mode_for_content_requests.md`). No original prompt,
no mockup, no decisions record exists.

This document reconstructs intent from the shipped YAML, then
redesigns the one section found to be structurally broken (the
Right-Sizing Scoreboard) so future changes have something to
anchor against. The Capacity section is preserved as-authored and
its intent captured retroactively; it is not being re-scoped here.

## Contents

**Super metrics (11):**

- [VCF Content Factory] Cluster - CPU Free % After HA
- [VCF Content Factory] Cluster - Memory Free % After HA
- [VCF Content Factory] Cluster - VMs That Fit (CPU, demand-based)
- [VCF Content Factory] Cluster - VMs That Fit (Memory, allocation-based)
- [VCF Content Factory] Cluster - Oversized VM Count
- [VCF Content Factory] Cluster - Undersized VM Count
- [VCF Content Factory] Cluster - Idle VM Count
- [VCF Content Factory] VM - Target vCPUs (oversized)
- [VCF Content Factory] VM - Target Memory GB (oversized)
- [VCF Content Factory] VM - Target vCPUs (undersized)
- [VCF Content Factory] VM - Target Memory GB (undersized)

**Views (2):**

- [VCF Content Factory] Cluster Capacity Overview
- [VCF Content Factory] VM Right-Sizing Candidates

**Dashboards (1):**

- [VCF Content Factory] Capacity Assessment & Right-Sizing

**Custom groups (1):**

- [VCF Content Factory] VMs - Right-Sizing Candidates

## Installation

Run the installer from the **package root** (two levels up from this file):

**Python (recommended):**
```
python3 ../../install.py
```

**PowerShell:**
```powershell
..\..\install.ps1
```

Both scripts support interactive prompts, CLI flags, and environment variables.
Run with `--help` (Python) or `-?` (PowerShell) for usage details.

## Manual import (drag-drop)

Files in this directory use community-native filenames for per-object UI import:

| File | VCF Ops UI dialog |
|---|---|
| `supermetric.json` | Administration > Super Metrics > Import |
| `Views.zip` | Manage > Views > Import |
| `Dashboard.zip` | Manage > Dashboards > Import |
| `customgroup.json` | Environment > Custom Groups > Import |
| `AlertContent.xml` | Alerts > Alert Definitions > Import |
| `Reports.zip` | Administration > Content > Reports > Import |

See the top-level `README.md` for important notes about limitations of
manual import vs the automated installer.

## Uninstallation

To remove all content installed by this bundle:

**Python:**
```
python3 ../../install.py --uninstall
```

**PowerShell:**
```powershell
..\..\install.ps1 -Uninstall
```

> **Note:** If this bundle includes dashboards or views, uninstall must be
> run as the `admin` user. Re-run with `--user admin` (Python) or
> `-User admin` (PowerShell), or set `VCFOPS_USER=admin`.

## Requirements

- Python 3.8+ or PowerShell 5.1+
- Network access to your VCF Operations instance
- VCF Operations user with write access to content and policies

---
_Generated by vcfops_packaging. Part of the VCF Content Factory framework._
