# IDPS Planner

# IDPS Planner

A VCF Operations dashboard for monitoring vDefend IDPS (Intrusion Detection
and Prevention System) resource consumption — designed specifically for
administrators running IDPS in **Classic Mode** to proactively track traffic
thresholds that trigger the IDPS Bypass feature.

## Purpose

By tracking Packets Per Second (PPS) and Throughput across your vDefend
environment, this dashboard surfaces hosts and VMs approaching performance
limits, ensuring security inspection coverage stays consistent and
effective.

## Key Performance Indicators

- **Classic Mode PPS** — identifies entities approaching 140k PPS.
- **Turbo Mode Throughput** — identifies entities approaching 9 Gbps.

> **Note on sampling.** When these thresholds are exceeded, the IDPS bypass
> mechanism may begin sampling traffic on the affected host to maintain
> system stability. Bypass behaviour applies on ESXi 8.0u3e or later with
> NSX 4.2.1 or later.

## Metric Definitions

Metrics use **peak values rather than averages** for a conservative,
safety-first view.

### 5-Minute Peak (Current)

- **Definition.** The highest value recorded for each VM during the most
  recent 5-minute collection interval.
- **Aggregation.** Sums per-host across VMs.
- **Observation.** Because per-VM peaks may occur at different seconds
  within the 5-minute window, the "Current" value is a high-water mark and
  may overstate simultaneous utilization.

### Period Peak

- **Definition.** The absolute highest traffic spike recorded for a host
  over the entire dashboard timeframe (e.g. last 24 hours or 7 days).
- **Use case.** Identifying bursty workloads that intermittently trigger
  bypass mode.

### 95th Percentile

- **Definition.** Statistical measure representing the 95th percentile of
  all peak values recorded for a given host over the dashboard timeframe.
- **Purpose.** Accounts for the fact that not all VM peaks occur
  simultaneously; filters out one-off outliers to provide a more realistic
  "sustained heavy load" figure for capacity planning.

## Authors

- Ryan Pletka
- Brock Peterson
- Joe Tietz
- Geoff Shukin
- Scott Bowe

## License

MIT.

## Provenance

Extracted from a live VCF Operations lab via the [VCF Content Factory](https://github.com/sentania-labs/vcf-content-factory)
extractor. The factory's value-add is the **install / uninstall automation**
and **dependency walking** — the bundle ships with scripts that import the
dashboard, sync its dependent views and super metrics, and enable any
required built-in metrics that aren't on by default. Original authors
retain all rights to the dashboard's design, queries, and view layout.

## Provenance

**Version:** 3.5

**Author:** Ryan Pletka, Brock Peterson, Joe Tietz, Geoff Shukin, Scott Bowe

**License:** MIT

## Contents

**Super metrics (5):**

- [IDPS] Net Receive (All VMs)
- [IDPS] Net Transmit (All VMs)
- [IDPS] Net Usage (All VMs)
- [IDPS] Packets per second (All VMs)
- [IDPS] Peak PPS within cycle (All VMs)

**Views (5):**

- [IDPS] IDPS Planner VM Metrics
- IDPS Planner - Cluster Selection
- IDPS Planner - Datacenter Selection
- IDPS Planner - vCenter Selection
- IDPS Planner Host Metrics

**Dashboards (1):**

- IDPS Planner

## Installation

Run the installer from the **package root** (two levels up from this file):

**Python (recommended):**
```
python3 ../../install.py
```

**PowerShell:**
```powershell
..\..\install.ps1
```

Both scripts support interactive prompts, CLI flags, and environment variables.
Run with `--help` (Python) or `-?` (PowerShell) for usage details.
See the top-level `README.md` **Authentication** section for supported auth sources
(Local, vCenter SSO, AD) and sources that are not supported (VIDB, VIDM).

> **Policy enablement caveat.** The install script enables imported super
> metrics on the **Default Policy** only. If your deployment uses
> non-default, non-inheriting policies, you may need to manually enable the
> imported super metrics in those policies — otherwise dashboard cells and
> view columns that depend on those metrics will appear blank for resources
> scoped under those policies. Check `Administration > Policies` after
> install to confirm enablement on every policy that needs to see the
> bundle's data.

## Manual import (drag-drop)

Files in this directory use community-native filenames for per-object UI import:

| File | VCF Ops UI dialog |
|---|---|
| `supermetric.json` | Administration > Super Metrics > Import |
| `Views.zip` | Manage > Views > Import |
| `Dashboard.zip` | Manage > Dashboards > Import |
| `customgroup.json` | Environment > Custom Groups > Import |
| `AlertContent.xml` | Alerts > Alert Definitions > Import |
| `Reports.zip` | Administration > Content > Reports > Import |

See the top-level `README.md` for important notes about limitations of
manual import vs the automated installer.

## Uninstallation

To remove all content installed by this bundle:

**Python:**
```
python3 ../../install.py --uninstall
```

**PowerShell:**
```powershell
..\..\install.ps1 -Uninstall
```

> **Note:** If this bundle includes dashboards or views, uninstall must be
> run as the `admin` user. Re-run with `--user admin` (Python) or
> `-User admin` (PowerShell), or set `VCFOPS_USER=admin`.

## Requirements

- Python 3.8+ or PowerShell 5.1+
- Network access to your VCF Operations instance
- VCF Operations user with write access to content and policies

---
_Generated by vcfops_packaging. Part of the VCF Content Factory framework._
